#!/usr/bin/python3
# Copyright (c) <year> <copyright holders>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
import enum
import json

from enum import Enum
from pathlib import Path
from typing import Union, Dict, List, Optional

import pydicom
from pydicom.errors import InvalidDicomError

"""
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "",
  "title": "Result Manifest",
  "description": "AI Marketplace result manifest file",
  "type": "object",
  "properties": {
    "contractVersion": {
      "description": "API Version",
      "type": "integer"
    },
    "fhirJson": {
      "description": "FHIR File",
      "type": "object",
      "properties": {
          "name": {
            "description": "FHIR file name",
            "type": "string"
          }
      }
      "required": [ "name" ]
    },
    "status": {
      "description": "Result status",
      "type": "object",
      "properties": {
        "code": {
          "description": "Status Code",
          "type": "string"
        },
        "text": {
          "description": "Reason",
          "type": "string"
        }
      },
      "required": [ "status", "text" ]
    },
    "study": {
      "description": "Collection of result artifacts",
      "type": "object",
      "properties": {
        "uid": {
          "description": "",
          "type": "string"
        },
        "artifacts": {
          "description": "Artifacts that aren't associated with a study",
          "type": "object",
          "properties": {
            "name": {
              "description": "file name of this artifact",
              "type": "string"
            },
            "documentType": {
              "description": "MIME type of this artifact",
              "type": "string"
            },
            "groupCode": {
              "description": "Identifier that can be used to group the result files in AI Marketplace if it can be determined.",
              "type": "string"
            }
            "trackingUids": {
              "description": "Unique identifier for grouping artifacts",
              "type": "array",
              "items": {
                "type": "string"
              }
            }
          }
        },
        "series": {
          "description": "Artifacts that are associated with a study",
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "uid": {
                "description": "Series UID",
                "type": "string"
              },
              "artifacts": {
                "description": "Artifacts that associated with a study",
                "type": "array",
                "items": {
                  "type": "object",
                  "properties": {
                    "name": {
                      "description": "file name of this artifact",
                      "type": "string"
                    },
                    "documentType": {
                      "description": "MIME type of this artifact",
                      "type": "string"
                    },
                    "trackingUids": {
                      "description": "Unique identifier for grouping artifacts",
                      "type": "array",
                      "items": {
                        "type": "string"
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  },
  "required": [ "contractVersion", "status" ]
}
"""

__version__ = "1.0.0.61"


class ResultStatus(enum.Enum):
    ANALYSIS_FAILED = "ANALYSIS_FAILED"
    ANALYSIS_PENDING = "ANALYSIS_PENDING"
    ANALYSIS_COMPLETE = "ANALYSIS_COMPLETE"
    LICENSE_EXPIRED = "LICENSE_EXPIRED"
    STUDY_NOT_APPLICABLE = "STUDY_NOT_APPLICABLE"

    def __str__(self):
        return self.value


class ResultException(Exception):
    def __init__(self, reason, *args):
        self.reason = str(reason)
        super(ResultException, self).__init__(reason, *args)


class MimeType(Enum):
    DICOM = "application/dicom"
    JSON = "application/json"
    LOG = "text/log"
    PDF = "application/pdf"
    UNKNOWN = "application/octet-stream"

    @classmethod
    def for_file(cls, filepath: Union[Path, str]):
        if isinstance(filepath, str):
            filepath = Path(filepath)
        return cls.for_suffix(filepath.suffix)

    @classmethod
    def for_suffix(cls, suffix: str):
        suffix = suffix.lower()
        if suffix in [".dcm", ".dicom", ".dic"]:
            return cls.DICOM
        elif suffix in [".json"]:
            return cls.JSON
        elif suffix in [".log"]:
            return cls.LOG
        elif suffix in [".pdf"]:
            return cls.PDF
        else:
            return cls.UNKNOWN


class Artifact:
    __slots__ = ["name", "document_type", "group_code", "tracking_uids"]

    def __init__(self, file_path: Path, document_type: Union[MimeType, str] = "", group_code: str = "default", tracking_uids: Optional[List[str]] = None):
        if tracking_uids is None:
            tracking_uids = []
        self.name = file_path.name
        if document_type:
            if isinstance(document_type, MimeType):
                self.document_type = document_type.value
            else:
                self.document_type = document_type
        else:
            self.document_type = MimeType.for_file(file_path).value
        self.group_code = group_code
        self.tracking_uids = tracking_uids

    @property
    def manifest(self) -> Dict:
        return {
            "documentType": self.document_type,
            "groupCode": self.group_code,
            "name": self.name,
            "trackingUids": self.tracking_uids
        }


class Result:
    def __init__(self, result_folder: Union[Path, str], fhir: Union[Path, str]):
        super(Result, self).__init__()
        if not issubclass(result_folder.__class__, (str, Path)):
            self.result_folder = Path(str(result_folder))
        elif issubclass(result_folder.__class__, str):
            self.result_folder = Path(result_folder)
        else:
            self.result_folder = result_folder
        self.__status: ResultStatus = ResultStatus.ANALYSIS_PENDING
        self.study_uid = ""
        self.reason = ""
        self.artifacts: Dict[str, List[Artifact]] = {}
        if isinstance(fhir, Path):
            self.fhir = self.result_folder / fhir.name
        else:
            self.fhir = self.result_folder / Path(fhir).name

    @property
    def manifest_v2(self) -> Dict:
        manifest = {
            "contractVersion": 2,
            "status": {
                "code": str(self.status),
                "text": self.reason,
            },
            "study": {
                "uid": self.study_uid,
                "artifacts": [],
                "series": []
            }
        }
        if self.status is ResultStatus.ANALYSIS_COMPLETE or self.fhir.exists():  # FHIR is required when for ANALYSIS COMPLETE, optional otherwise
            manifest["fhirJson"] = {"name": self.fhir.name}
        for uid, artifacts in self.artifacts.items():
            if uid:  # a series_uid sets this to be a series
                manifest["study"]["series"].append({"uid": uid, "artifacts": [artifact.manifest for artifact in artifacts]})
            else:  # an unspecified series_uid sets this to a blank string
                manifest["study"]["artifacts"].extend([artifact.manifest for artifact in artifacts])
        return manifest

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, new_status):
        if isinstance(new_status, ResultStatus):
            self.__status = new_status
        else:
            self.__status = ResultStatus(str(new_status))

    def add_artifact(self, document: Union[Artifact, Path, str], series_uid: str = "", group_code: str = "", content_type: str = "", tracking_uids: Optional[List[str]] = None) -> Path:
        if not isinstance(document, Artifact):
            if isinstance(document, str):
                document_path = Path(document)
            else:
                document_path = document
            artifact = Artifact(document_path, content_type, group_code, tracking_uids)
        else:
            artifact = document
        if self.study_uid == "":
            try:
                with pydicom.dcmread(str(self.result_folder / artifact.name), defer_size=32) as open_instance:
                    self.study_uid = open_instance.StudyInstanceUID
            except InvalidDicomError:
                pass
        if artifact.name != self.fhir.name:
            try:
                self.artifacts[series_uid].append(artifact)
            except KeyError:
                self.artifacts[series_uid] = [artifact]
        return self.result_folder / artifact.name

    def add_series_image(self, image: Union[Artifact, Path, str], series_uid: str, group_code: str = "", content_type: str = "", tracking_uids: Optional[List[str]] = None) -> Path:
        if series_uid:
            return self.add_artifact(image, series_uid, group_code, content_type, tracking_uids)
        else:
            raise ResultException("Series Instance UID must be specified.")

    def fail(self, reason: str = ""):
        self.set_transaction_status(ResultStatus.ANALYSIS_FAILED, reason)

    def manifest(self, version: int = 2):
        if version == 2:
            return self.manifest_v2
        return {}

    def not_licensed(self, reason: str = ""):
        self.set_transaction_status(ResultStatus.LICENSE_EXPIRED, reason)

    def set_transaction_status(self, status: ResultStatus = ResultStatus.ANALYSIS_COMPLETE, reason: str = ""):
        self.status = status
        self.reason = reason

    def refuse(self, reason: str = ""):
        self.set_transaction_status(ResultStatus.STUDY_NOT_APPLICABLE, reason)

    def succeed(self, reason: str = ""):
        self.set_transaction_status(ResultStatus.ANALYSIS_COMPLETE, reason)

    def write(self, contract_version: int = 2):
        self.result_folder.mkdir(parents=True, exist_ok=True)
        manifest_file = self.result_folder / "resultManifest.json"
        if manifest_file.exists():
            manifest_file.unlink()
        if contract_version == 2:
            manifest_file.write_text(json.dumps(self.manifest_v2, indent=2))
        else:
            raise ResultException(f"No manifest defined for contract version {contract_version}")


def load_result_file(result_file: Union[Path, str]) -> Result:
    """
    Parameters
    ----------
    result_file: Union[Path, str]
        File that describes the Result to be built

    Returns
    -------
        A Result object from result_file.  The result folder is the parent of the resultManifest.json
    """
    if not issubclass(result_file.__class__, (str, Path)):
        result_file = Path(str(result_file))
    elif issubclass(result_file.__class__, str):
        result_file = Path(result_file)

    new_result = Result(result_file.expanduser().resolve().absolute().parent)
    result_json = json.load(result_file.open())

    new_result.fhir = result_json["fhirJson"]["name"]
    new_result.status = result_json["status"]["code"]
    new_result.reason = result_json["status"]["text"]
    if "artifacts" in result_json["study"]:
        for artifact in result_json["study"]["artifacts"]:
            new_result.add_artifact(Path(artifact["name"]), group_code=artifact["groupCode"],
                                    content_type=artifact["documentType"], tracking_uids=artifact.get("trackingUids", []))
    for series in result_json["series"]:
        for artifact in series["artifacts"]:
            new_result.add_series_image(Path(artifact["name"]), series["uid"], group_code=artifact["groupCode"],
                                        content_type=artifact["documentType"], tracking_uids=artifact.get("trackingUids", []))
    return new_result
