"""
Copyright (c) 2020 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import sys
from threading import Lock, Thread
from traceback import format_exc
from typing import Optional

from flask import abort, Flask

import ai_service.service
from ai_service.__metadata__ import __description__, __version__
from ai_service.environment import SELF_HOSTED
from ai_service.logs import get_logger
from ai_service.ai_job import AiJob

logger = get_logger("controller")
ai_controller = Flask("AI Service")
ai_service: ai_service.service.AiService
self_hosted_thread: Optional[Thread] = None
job_lock = Lock()


@ai_controller.route("/aiservice/2/shutdown", methods=["POST"])
@ai_controller.route("/aiservice/1/shutdown", methods=["POST"])
def shutdown():
    logger.debug("Received shutdown request")
    try:
        ai_service.shutdown()
    except AttributeError:
        __no_ai_service()
    return "OK"


@ai_controller.route("/aiservice/2/live", methods=["GET"])
@ai_controller.route("/aiservice/1/live", methods=["GET"])
def health():
    logger.debug("Received liveness check")
    try:
        message = f"{ai_service.ai_job_processor.partner_name} " \
                  f"{ai_service.ai_job_processor.service_name} " \
                  f"{ai_service.ai_job_processor.version}"
        if ai_service.check_liveness():
            message = f"{message} using {__description__} {__version__}"
            logger.debug(message)
            return message
        else:
            logger.debug(f"{message} is not OK")
            abort(500, "NOT OK")
    except AttributeError:
        __no_ai_service()


@ai_controller.route("/aiservice/2/ready", methods=["GET"])
def ready():
    logger.debug("Received Readiness check")
    try:
        message = f"{ai_service.ai_job_processor.partner_name} {ai_service.ai_job_processor.service_name} " \
                  f"{ai_service.ai_job_processor.version} using {__description__} {__version__}"
        if ai_service.ready:
            message = f"{message} is ready!"
            logger.debug(message)
            return message
        else:
            message = f"{message} is not quite ready!"
            logger.debug(message)
            abort(503, "NOT QUITE YET")
    except AttributeError:
        __no_ai_service()


@ai_controller.route("/aiservice/2/jobs", methods=["POST"])
@ai_controller.route("/aiservice/1/jobs", methods=["POST"])
def process_job():
    logger.debug("Received job request")
    try:
        if ai_service.check_liveness():
            # import the request object for use
            # do this here to be certain that the correct object is copied to our namespace
            from flask import request
            logger.debug(request.json)
            ai_job = AiJob(request.json)
            try:
                logger.debug(request.headers)
                if SELF_HOSTED:
                    with job_lock:
                        global self_hosted_thread
                        if self_hosted_thread is not None and self_hosted_thread.is_alive():
                            abort(503, f"Only 1 job may run concurrently.")
                        # Self-Hosted service without a defined Message Queue
                        ai_job.authorization = request.headers["Authorization"]
                        self_hosted_thread = Thread(target=__process_self_hosted_job, args=[ai_job])
                        self_hosted_thread.start()
                else:
                    ai_service.process_job(ai_job)
            except KeyError:
                abort(400, "Request MUST include Authorization header")
            except Exception as e:  # Exceptions are non-exit exceptions
                logger.warning(e)
                logger.debug(format_exc())
                abort(500, "Service encountered an exception")
        else:
            abort(503, f"Service cannot process jobs")
    except AttributeError as e:
        logger.debug(e)
        __no_ai_service()
    logger.info("Closing job request")
    return "OK"


def set_ai_service(_ai_service):
    global ai_service
    logger.debug("Setting AI Service in AI Controller")
    ai_service = _ai_service


def __no_ai_service():
    abort(501, "No AI Service")


def __process_self_hosted_job(ai_job):
    try:
        ai_service.process_job(ai_job)
    except Exception:
        # unpack the exception components and pass them to the exception hook setup in service
        sys.excepthook(*sys.exc_info())
