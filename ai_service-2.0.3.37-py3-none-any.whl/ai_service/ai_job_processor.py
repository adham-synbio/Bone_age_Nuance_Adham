"""
Copyright (c) 2020 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import contextlib
import logging
import shutil
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from queue import Queue, Empty
from threading import Thread, RLock
from typing import List, Union, Optional, Set

from pydicom import Dataset

from ai_service import subprocess
from ai_service.ai_job import AiJob
from ai_service.dicom_image import Series
from ai_service.environment import GB, MIN_FREE_DISK_GB, SECRET_KEY, SUBSCRIPTION_KEY, TEMP_DIR, UNDEAD_FILE
from ai_service.logs import get_logger
from ai_service.utility import DICOM_GSPS_MIME_TYPE, DICOM_MIME_TYPE, DICOM_SC_MIME_TYPE, DICOM_SR_MIME_TYPE
from ai_service.utility import _Document, _seconds_ago, AiServiceException
from result import ResultStatus

_ADD_DOCUMENT_PATH = "/{VERSION}/transactions/{TRANSACTION_ID}/results/{RESULT_ID}/documents"
_BACKGROUND_THREAD_COUNT = 4
_COMPLETE_RESULT_PATH = "/{VERSION}/transactions/{TRANSACTION_ID}"
_CREATE_RESULT_PATH = "/{VERSION}/transactions/{TRANSACTION_ID}/results"
_IMAGE_FOLDER_NAME = "images"
_IMAGE_MILESTONE = 100
_MANIFEST_FILE = "job-response"

_logger = get_logger("ai.job_processor")


class AiJobProcessor(ABC):
    logger = get_logger("ai.job_processor.AiJobProcessor")
    partner_name = "undefined_partner"
    service_name = "undefined_service"
    version = "0.0.0.1"
    """
    Processes AI Jobs.

    This class should be extended by PIN partners for ease of integration and to provide common implementation.

    Parameters
    ----------
    ai_job : AiJob
        Job to be processed by this job processor.

    Attributes
    ----------
    partner_name : str
        Name of the Partner who implemented this service.
    service_name : str
        Name of this service.
    version : str
        Version of this service
    logger : Logger
        Logger instance provided for easy logging.

    Examples
    ----------
    class AcmeAi(AiJobProcessor)

    See Also
    ----------
    ai_service.AiJob : Job processed.
    """

    service_configuration = {
    }
    subscriber_configuration = {
    }
    subscription_configuration = {
    }

    __complete_lock = RLock()
    __add_document_for_upload_lock = RLock()

    def __init__(self, ai_job: Optional[AiJob] = None):
        self.logger.debug(f"Subscription Key is {SUBSCRIPTION_KEY}")
        if ai_job:
            self.ai_job = ai_job

            # update the configurations
            # Create a new dictionary
            service_configuration = {}
            # Obtain values from our class
            service_configuration.update(AiJobProcessor.service_configuration)
            # Obtain values from their class (the instance value hasn't been assigned yet)
            service_configuration.update(self.service_configuration)
            # Obtain values from ai job
            try:  # https://docs.python.org/3/glossary.html#term-eafp
                service_configuration.update(self.ai_job.configuration["service"])
            except (TypeError, KeyError):
                self.logger.debug("No service configuration from AI Marketplace")
            # set instance value, this will mask the class value (not over write it)
            self.service_configuration = service_configuration

            # Create a new dictionary
            subscriber_configuration = {}
            # Obtain values from our class
            subscriber_configuration.update(AiJobProcessor.subscriber_configuration)
            # Obtain values from their class (the instance value hasn't been assigned yet)
            subscriber_configuration.update(self.subscriber_configuration)
            # Obtain values from ai job
            try:  # https://docs.python.org/3/glossary.html#term-eafp
                subscriber_configuration.update(self.ai_job.configuration["subscriber"])
            except (TypeError, KeyError):
                self.logger.debug("No subscriber configuration from AI Marketplace")
            # set instance value, this will mask the class value (not over write it)
            self.subscriber_configuration = subscriber_configuration

            # Create a new dictionary
            subscription_configuration = {}
            # Obtain values from our class
            subscription_configuration.update(AiJobProcessor.subscription_configuration)
            # Obtain values from their class (the instance value hasn't been assigned yet)
            subscription_configuration.update(self.subscription_configuration)
            # Obtain values from ai job
            try:  # https://docs.python.org/3/glossary.html#term-eafp
                subscription_configuration.update(self.ai_job.configuration["subscription"])
            except (TypeError, KeyError):
                self.logger.debug("No subscription configuration from AI Marketplace")
            # set instance value, this will mask the class value (not over write it)
            self.subscription_configuration = subscription_configuration

            self.__documents: Queue[Optional[_Document]] = Queue()
            self.__result_start_time: Optional[datetime] = None

            self.logger = ai_job.logger
            self.log_writer = self.logger.log_writer()
            self.error_log_writer = self.logger.log_writer(level=logging.ERROR)
            self.exceptions: Set[AiServiceException] = set()

    @property
    def upload_log(self):
        # Dig through ALL the configurations from most general to most specific
        upload_log = False
        configured = self.__upload_log(self.service_configuration)
        if configured is not None:
            self.logger.debug(f"Service Configuration uploadLog: {configured}")
            upload_log = configured
        configured = self.__upload_log(self.subscriber_configuration)
        if configured is not None:
            self.logger.debug(f"Subscriber Configuration uploadLog: {configured}")
            upload_log = configured
        configured = self.__upload_log(self.subscription_configuration)
        if configured is not None:
            self.logger.debug(f"Subscription Configuration uploadLog: {configured}")
            upload_log = configured
        self.logger.info(f"uploadLog set to {upload_log}")
        return upload_log

    @staticmethod
    def __upload_log(configurations) -> Optional[bool]:
        _configurations = [configurations]
        for configuration in _configurations:
            for key, value in configuration.items():
                if key == "uploadLog":
                    return str(value).lower() == "true"
                if isinstance(value, dict):
                    _configurations.append(value)
        return None

    def authorize(self):
        return self.ai_job.authorization == SECRET_KEY

    def initialize(self):
        pass

    @classmethod
    def initialize_class(cls):
        pass

    def teardown(self):
        pass

    @abstractmethod
    def filter_image(self, image: Dataset) -> bool:
        """
        The first step of processing a job is to examine DICOM images and filter out unsuitable images.
        DICOM tags such as modality and body part should be considered.
        Please remember that some tags are optional.

        Parameters
        ----------
        image : Dataset
            An open Dataset to be evaluated

        Returns
        -------
        bool
            True if this image should be kept, False if it should not
        """
        raise NotImplementedError

    @classmethod
    def check_liveness(cls) -> bool:
        """
        Evaluates three things to determine if this service is functioning properly:
          1.  Duration of incomplete jobs
          2.  Available disk space... this will run out if the service isn't cleaning up after itself
          3.  Existence of the "Zombie File", this file can be touched to cause the liveness checks to fail

        Returns
        -------
        bool
            True if the service is healthy
        """
        alive = True
        if MIN_FREE_DISK_GB > 0:
            free_disk_gb = shutil.disk_usage(TEMP_DIR).free / GB
            if free_disk_gb < MIN_FREE_DISK_GB:
                cls.logger.warning(f"Only {int(free_disk_gb)} GB of disk space available, "
                                   f"{MIN_FREE_DISK_GB} GB is required")
                alive = False
        if UNDEAD_FILE.exists():
            cls.logger.warning("Service is unhealthy")
            cls.logger.info(UNDEAD_FILE.read_text())
            alive = False
        return alive

    @abstractmethod
    def select_series(self, image_series_list: List[Series]) -> List[Series]:
        """
        After DICOM images have been filtered, they are collated by series.
        AI Services must select series that should be analyzed.
        Many AI services analyze a single series and select the "best" one for analysis.
        Some AI services select multiple series.

        Parameters
        ----------
        image_series_list : List[Series]
            AI Services are passed a list of series.
            Each series is a list of DICOM images as opened by pydicom.dcmread().
            Therefore image_series_list is a list of lists of images:
            [
              [ series1_image1, series1_image2 ],
              [ series2_image1, series2_image2 ]
            ]

        Returns
        -------
        List[Series]
            List of lists of images that meet the appropriate criteria.
            The return value should be the same structure as the input value.
        """
        raise NotImplementedError

    def select_prior_series(self, image_series_list: List[Series]) -> List[Series]:
        """
        After DICOM images have been filtered, they are collated by series.
        AI Services must select series that should be analyzed.
        Many AI services analyze a single series and select the "best" one for analysis.
        Some AI services select multiple series.

        Parameters
        ----------
        image_series_list : List[Series]
            AI Services are passed a list of series.
            Each series is a list of DICOM images as opened by pydicom.dcmread().
            Therefore image_series_list is a list of lists of images:
            [series1, series2]

        Returns
        -------
        List[Series]
            List of lists of images that meet the appropriate criteria.
            The return value should be the same structure as the input value.
        """
        self.logger.info("Using default series selection for prior series")
        return self.select_series(image_series_list)

    @abstractmethod
    def process_study(self):
        """
        Do the actual work to process this study.
        DICOM images that have been filtered and selected are available in self.ai_job.selected_series_list.
        The files that back these images are located in self.ai_job.image_folder.

        Full implementation of this method should include partner logic for analyzing a study
        and calls to upload_document to include analysis output in the results reported to AI Marketplace.
        See the documentation for AIM Service for a full reference of available values.

        Returns
        -------
        None
        """
        raise NotImplementedError

    @classmethod
    def shutdown(cls):
        """
        Partner integration for AI Service shutdown.

        Returns
        -------
        None
        """
        cls.logger.debug("Shutdown method called")

    def upload_dicom(self, file: Union[Path, str], document_detail: str = "", group_code: str = "default",
                     series_uid: Optional[str] = None, tracking_uids: Optional[List[str]] = None):
        self.upload_document(file, DICOM_MIME_TYPE, document_detail, group_code, series_uid, tracking_uids)

    def upload_gsps_dicom(self, file: Union[Path, str], document_detail: str = "", group_code: str = "default",
                          series_uid: Optional[str] = None, tracking_uids: Optional[List[str]] = None):
        self.upload_document(file, DICOM_GSPS_MIME_TYPE, document_detail, group_code, series_uid, tracking_uids)

    def upload_sc_dicom(self, file: Union[Path, str], document_detail: str = "", group_code: str = "default",
                        series_uid: Optional[str] = None, tracking_uids: Optional[List[str]] = None):
        self.upload_document(file, DICOM_SC_MIME_TYPE, document_detail, group_code, series_uid, tracking_uids)

    def upload_sr_dicom(self, file: Union[Path, str], document_detail: str = "", group_code: str = "default",
                        series_uid: Optional[str] = None, tracking_uids: Optional[List[str]] = None):
        self.upload_document(file, DICOM_SR_MIME_TYPE, document_detail, group_code, series_uid, tracking_uids)

    def upload_document(self, file: Union[Path, str], content_type: str = "", document_detail: str = "",
                        group_code: str = "default", series_uid: Optional[str] = None,
                        tracking_uids: Optional[List[str]] = None):
        """
        Parameters
        ----------
        file : Path
        content_type : str
            Content-Type for this document
        document_detail : str
            Description of this document for AI Marketplace
        group_code : str
            Group code is a free text field that can be used to associate documents
        series_uid : Optional[str]
            The UID for the series this document is associated with, not used for V1 services.
        tracking_uids : Optional[List[str]]
            Tracking UIDs this document is associated with, not used for V1 services.

        Returns
        -------
        None
        """
        # This lock is to ensure that only one result is created for a given study
        # and that only four threads are started
        with self.__add_document_for_upload_lock:
            # Queue up a document first, then start the threads to process it.
            # This limits the race condition where two documents are added and each one triggers threads starting
            if not issubclass(file.__class__, (str, Path)):
                file = Path(str(file))
            elif issubclass(file.__class__, str):
                file = Path(file)
            if file.is_file():
                self.__documents.put(
                    _Document(file, document_type=content_type, document_detail=document_detail, group_code=group_code,
                              series_uid=series_uid, tracking_uids=tracking_uids)
                )

                if self.__result_start_time is None:
                    self.__result_start_time = datetime.now()
                    # Prepare to upload results, for some output_study_access types these will be largely idle
                    for _ in range(_BACKGROUND_THREAD_COUNT):
                        Thread(target=self.__upload_documents, daemon=True).start()
            elif file.is_dir():
                for f in file.iterdir():
                    self.upload_document(f, content_type, document_detail, group_code, series_uid, tracking_uids)

    def check_license(self) -> bool:
        """
        Partner integration for license verification.

        Returns
        -------
        bool
            True if the license is valid.
        """
        self.logger.debug("License Valid")
        return True

    def set_transaction_status(self, status: Union[ResultStatus, str] = ResultStatus.ANALYSIS_COMPLETE,
                               reason: str = ""):
        """
        Complete the AI Job, this method is always called.

        Parameters
        ----------
        status : Union[str, ResultStatus]
            Status to be set, failure or other statuses must be explicitly specified
        reason : str
            Optional explanation of completion.

        Returns
        -------
        None
        """
        # This lock is to ensure that only one thread can attempt to complete a result at a time
        self.logger.debug(f"Preparing to complete AI Job {self.ai_job.transaction_id}")
        if not self.ai_job.completed:
            with self.__complete_lock:
                self.logger.debug(f"AI Job is {'complete' if self.ai_job.completed else 'incomplete'}")
                if not self.ai_job.completed:
                    # Include the log file if requested
                    if self.upload_log:
                        self.logger.debug(f"Uploading {self.ai_job.log_file}")
                        # Add the log file as LATE as possible so the upload includes as much of the log as possible
                        self.__documents.join()
                        self.upload_document(self.ai_job.log_file)
                    # Wait for uploads to complete so all possible exceptions are available
                    self.__documents.join()
                    # raise exceptions if any have occurred
                    if self.exceptions:
                        exception = next(iter(self.exceptions))
                        self.exceptions.clear()
                        raise exception
                    # complete result
                    try:
                        self.__complete_result(ResultStatus(status), reason)
                    except ValueError:
                        _logger.warning(f"Could not recognize the status '{status}', using 'ANALYSIS_FAILED' instead")
                        self.__complete_result(ResultStatus.ANALYSIS_FAILED, reason)
                    message = f"Uploaded AI Job {self.ai_job.transaction_id} results"
                    if self.__result_start_time is not None:  # __result_start_time is set when documents are uploaded
                        message = f"{message} in {_seconds_ago(self.__result_start_time)} seconds"
                    self.logger.info(message)
                    self.__result_start_time = None

    def mark_unhealthy(self, reason):
        self.logger.warning(reason)
        UNDEAD_FILE.write_text(reason)

    def __upload_documents(self):
        self.logger.debug("Upload thread started")
        while not self.ai_job.completed:
            try:
                document = self.__documents.get(timeout=1)
                try:
                    if document:
                        self.logger.debug(f"Uploading {document.file_path} as {document.document_type}")
                        self.ai_job.output_study_access.put(document)
                        self.logger.debug(f"Uploaded {document.file_path} as {document.document_type}")
                except AiServiceException as e:
                    self.exceptions.add(e)
                    self.logger.warning(f"Failed to upload {document.file_path} as {document.document_type}")
                finally:
                    self.__documents.task_done()
            except Empty:
                pass
        self.logger.debug("Upload thread complete")

    def __complete_result(self, status: ResultStatus = ResultStatus.ANALYSIS_COMPLETE, reason: str = ""):
        self.logger.debug(f"Waiting for documents to upload for AI Job {self.ai_job.transaction_id}")
        with self.__add_document_for_upload_lock:  # block uploads from being added to the queue
            self.__documents.join()  # Wait for active uploads to complete, this  might be superfluous
            self.logger.debug(f"All documents uploaded for AI Job {self.ai_job.transaction_id} ")
            if status == ResultStatus.ANALYSIS_COMPLETE:
                self.ai_job.status = self.ai_job.output_study_access.complete_result(status)
            else:
                self.ai_job.status = self.ai_job.output_study_access.complete_result(status, reason)

            # Force the upload threads to notice that this job has completed and unravel before we give up the lock
            for i in range(_BACKGROUND_THREAD_COUNT):
                self.__documents.put(None)
