# Copyright (c) 2020 Nuance Communications, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit
# persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the
# Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from ai_service.__metadata__ import __description__, __version__
from ai_service.ai_job import AiJob
from ai_service.ai_job_processor import AiJobProcessor
from ai_service.dicom_image import PRIMARY_STUDY_KEY, PRIOR_STUDY_KEY, Study, Series, Image, related_uid
from ai_service.environment import LOGGING_LEVEL, KEEP_FILES, MAX_THREADS, MIN_FREE_DISK_GB, REQUEST_PORT
from ai_service.environment import SUBSCRIPTION_KEY, TEMP_DIR
from ai_service.service import AiService
from ai_service.utility import AiServiceException


# We only expose what the partner is expected to use
__all__ = (
    "__description__",
    "__version__",
    "AiJobProcessor",
    "AiJob",
    "AiService",
    "AiServiceException",
    "decompress_dicom",
    "Image",
    "LOGGING_LEVEL",
    "KEEP_FILES",
    "MAX_THREADS",
    "MIN_FREE_DISK_GB",
    "PRIMARY_STUDY_KEY",
    "PRIOR_STUDY_KEY",
    "related_uid",
    "REQUEST_PORT",
    "Series",
    "SUBSCRIPTION_KEY",
    "Study",
    "TEMP_DIR",
)
