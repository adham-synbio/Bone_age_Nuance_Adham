"""

Copyright (c) 2020 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Dict, Optional, List, Iterable

import pydicom
from pydicom import Dataset
from requests import Session
from requests.adapters import HTTPAdapter
from urllib3 import Retry

from ai_service.environment import SUBSCRIPTION_KEY
from ai_service.logs import get_logger
from result import ResultStatus

DICOM_MIME_TYPE = "application/dicom"
DICOM_GSPS_MIME_TYPE = "application/gsps+dicom"
DICOM_SC_MIME_TYPE = "application/sc+dicom"
DICOM_SR_MIME_TYPE = "application/sr+dicom"
JSON_MIME_TYPE = "application/json"

DICOM_MEDIA_TYPE = DICOM_MIME_TYPE
DICOM_GSPS_MEDIA_TYPE = DICOM_GSPS_MIME_TYPE
DICOM_SC_MEDIA_TYPE = DICOM_SC_MIME_TYPE
DICOM_SR_MEDIA_TYPE = DICOM_SR_MIME_TYPE
JSON_MEDIA_TYPE = JSON_MIME_TYPE

logger = get_logger("utility")
__session_retry = 3


def cancel_retries():
    global session
    session = __requests_retry_session(0)
    logger.info("Retries canceled")


def reset_session():
    global session
    session = __requests_retry_session(__session_retry)
    logger.info("Session Retries Reset")


class _Counter:
    def __add__(self, other):
        with self.__lock:
            self.__count += other
        return self

    def __iadd__(self, other):
        with self.__lock:
            self.__count += other
        return self

    def __init__(self):
        self.__lock = Lock()
        self.__count = 0

    def __int__(self):
        return self.__count

    def __mod__(self, other):
        return self.__count % other

    def __str__(self):
        return str(self.__count)


class _Document:
    __slots__ = ["__file_path", "__document_type", "document_detail", "group_code", "series_uid", "tracking_uids"]
    __document_types = {
        ".dcm": DICOM_MIME_TYPE,
        ".dicom": DICOM_MIME_TYPE,
        ".dic": DICOM_MIME_TYPE,
        ".log": "text/log",
        ".json": JSON_MIME_TYPE,
        ".pdf": "application/pdf",
    }
    __unknown_document_type = "application/octet-stream"

    def __init__(self, file_path: Path, document_type: str = "", document_detail: str = "", group_code: str = "default",
                 series_uid: Optional[str] = None, tracking_uids: Optional[List[str]] = None):
        self.__file_path = file_path
        self.__document_type = document_type
        self.document_detail = document_detail
        self.group_code = group_code
        if series_uid:
            self.series_uid = series_uid
        else:
            self.series_uid = ""
        if tracking_uids is not None:
            self.tracking_uids = tracking_uids
        else:
            self.tracking_uids = []
        if not (self.tracking_uids and self.series_uid) and self.document_type in [
            DICOM_MEDIA_TYPE, DICOM_GSPS_MEDIA_TYPE, DICOM_SC_MEDIA_TYPE, DICOM_SR_MEDIA_TYPE
        ]:
            with pydicom.dcmread(file_path, defer_size=32) as open_dicom:
                if not self.series_uid:
                    try:
                        self.series_uid = open_dicom.SeriesInstanceUID
                    except AttributeError:
                        pass
                if not self.tracking_uids:
                    try:
                        self.tracking_uids.append(open_dicom.TrackingUID)
                    except AttributeError:
                        pass

    def __str__(self):
        return f"{self.file_path.name},{self.document_type},{self.file_path}"

    @property
    def data(self) -> Dict:
        return {
            "documentType": self.document_type,
            "documentTypeDetail": self.document_detail or "",
            "name": self.file_path.name,
        }

    @property
    def document_type(self):
        return self.__document_type or self.__document_types.get(self.file_path.suffix, self.__unknown_document_type)

    @document_type.setter
    def document_type(self, document_type: str):
        self.__document_type = document_type

    @property
    def file_path(self):
        return self.__file_path.resolve().absolute()

    @file_path.setter
    def file_path(self, file_path: Path):
        self.__file_path = file_path

    @property
    def files(self) -> Dict:
        return {
            "file": (
                self.file_path.name,
                self.file_path.open("rb"),
                self.document_type
            )
        }


def __requests_retry_session(retries: int) -> Session:
    """Returns a Session configured for retries (or not if retries have been canceled)"""
    _session = Session()
    _adapter = HTTPAdapter(max_retries=Retry(
        total=retries,
        backoff_factor=1.0,  # {backoff_factor} * (2 ** ({number of total retries} - 1))
        allowed_methods=frozenset(["GET", "POST", "PUT"]),
        status_forcelist=(401, 404, 405, 500, 502, 503, 504),
    ))
    _session.mount("http://", _adapter)
    _session.mount("https://", _adapter)
    # Set the headers for the entire session
    _session.headers = {"Ocp-Apim-Subscription-Key": SUBSCRIPTION_KEY}
    return _session


def _mask_keys(dictionary: Dict) -> Dict:
    masked_dictionary = {}
    for key, value in dictionary.items():
        if key == "uris":
            masked_dictionary[key] = len(value)
        elif "Key" in key:
            masked_dictionary[key] = "**********"
        elif issubclass(value.__class__, Path):
            masked_dictionary[key] = str(value)
        else:
            masked_dictionary[key] = value
    return masked_dictionary


def _seconds_ago(then) -> float:
    return (datetime.now() - then).total_seconds()


def copy_from_dataset(to_update: Dataset, source: Dataset, tags: Iterable[int]):
    for tag in tags:
        if tag in source:
            value_to_copy = source.get(tag)
            if value_to_copy is not None:
                to_update.add(value_to_copy)
    return to_update


class AiServiceException(Exception):
    def __init__(self, reason, *args):
        self.reason = str(reason)
        super(AiServiceException, self).__init__(reason, *args)


class AiServiceStatusException(AiServiceException):
    def __init__(self, reason, status, *args):
        self.status = status
        super(AiServiceStatusException, self).__init__(reason, *args)


class AiServiceUnlicensedException(AiServiceStatusException):
    def __init__(self, reason, *args):
        super(AiServiceUnlicensedException, self).__init__(reason, ResultStatus.LICENSE_EXPIRED, *args)


class AiServiceNotApplicableException(AiServiceStatusException):
    def __init__(self, reason, *args):
        super(AiServiceNotApplicableException, self).__init__(reason, ResultStatus.STUDY_NOT_APPLICABLE, *args)


session = __requests_retry_session(__session_retry)
