"""

Copyright (c) 2020 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
from datetime import timedelta, datetime
from os import PathLike
from pathlib import Path
from threading import Lock
from typing import List, Dict, Iterator, Union, Optional

from pydicom import Dataset

from ai_service.dicom_image import PRIMARY_STUDY_KEY, PRIOR_STUDY_KEY, Image, Series, Study
from ai_service.environment import TEMP_DIR, _CONFIGURATION
from ai_service.logs import get_logger, get_transaction_logger
from ai_service.study_access import _StudyAccess, _FileFolderStudyAccess, UNSET_INPUT_STUDY_ACCESS
from ai_service.study_access import UNSET_OUTPUT_STUDY_ACCESS, _AIM_TRANSACTION_MANAGER
from ai_service.utility import _mask_keys, AiServiceException

_IMAGE_FOLDER_NAME = "images"
_logger = get_logger("ai.job")


class AiJob:
    """
    Class representation of an AI Job request from AI Marketplace.
    """
    partner_name = ""
    service_name = ""

    def __init__(self, message):
        """
        Parameters
        ----------
        message : dict
            JSON body from Create Job request.
        """
        self.__start_time = datetime.now()
        self.__duration = None
        self.__lock = Lock()

        # This is a dictionary of dictionaries of studies keyed by type, then by StudyInstanceUID
        self.__studies_by_type: Dict[str, Dict[str, Study]] = {
            PRIMARY_STUDY_KEY: {},
            PRIOR_STUDY_KEY: {}
        }

        # Default members related to accessing studies.  These are set as read only.
        self.input_study_access: _StudyAccess = UNSET_INPUT_STUDY_ACCESS
        self.__status: Optional[str] = None

        self.output_study_access: _StudyAccess = UNSET_OUTPUT_STUDY_ACCESS
        self.version = message.get("contractVersion", 1)

        if "Authorization" in message:
            self.authorization = message["Authorization"]
        else:
            self.authorization = ""

        self.configuration = {}
        self.configuration.update(_CONFIGURATION)
        if "configuration" in message:
            self.configuration.update(message["configuration"])
        try:
            if self.version == 1:
                self.transaction_id = message["transactionId"]
                self.input_study_access = _StudyAccess(self.transaction_id, {
                    "type": _AIM_TRANSACTION_MANAGER,
                    "aimTransactionManager": {
                        "url": message["transactionURL"] + f"/{self.version}/transactions/{self.transaction_id}"
                    }
                }, sources=message["uris"])
                self.output_study_access = self.input_study_access
                self.input_study_access.version = 1
            elif self.version == 2:
                self.transaction_id = message["transaction"]["transactionId"]
                self.input_study_access = _StudyAccess(self.transaction_id, message["inputDataAccess"]["studyAccess"],
                                                       sources=message["studies"])
                self.output_study_access = _StudyAccess(self.transaction_id, message["outputDataAccess"]["studyAccess"])
            else:
                raise AiServiceException(f"AiJob contract version {self.version} is not implemented")
            _logger.debug(f"Input StudyAccess is '{self.input_study_access.access_type}'")
            _logger.debug(f"Output StudyAccess is '{self.output_study_access.access_type}'")
        except KeyError as e:
            raise AiServiceException(f"AiJob does not contain {e}")

        self.__hash = hash(self.transaction_id)
        self.folder = TEMP_DIR / str(self.transaction_id)
        self.image_folder.mkdir(parents=True, exist_ok=True)

        self.log_file = self.folder / f"{self.partner_name}-{self.service_name}.log"
        self.logger = get_transaction_logger(self.transaction_id)
        self.logger.separate()
        self.logger.add_file(self.log_file)

        if self.authorization:
            self.logger.debug(f"Authorization set to {self.authorization}")
        self.logger.debug(f"Logging to {self.log_file}")
        self.logger.info(f"Created AI Job {self.transaction_id}")
        self.logger.debug(f"Created from {_mask_keys(message)}")
        self.logger.info(f"Configuration: {_mask_keys(self.configuration)}")

    def __eq__(self, other):
        return isinstance(other, self.__class__) and hash(self) == hash(other) and self.image_count == other.image_count

    def __hash__(self):
        return self.__hash

    def add_image(self, new_image: Union[Dataset, Image, Path, PathLike, str], study_type: str = PRIMARY_STUDY_KEY):
        # Adding keys to dictionaries is not thread safe!
        with self.__lock:
            if not isinstance(new_image, Image):
                new_image = Image(new_image)
            self.logger.debug(f"Adding {new_image} to {study_type}")
            if study_type not in self.__studies_by_type:
                self.__studies_by_type[study_type] = {new_image.study_uid: Study(image=new_image)}
            elif new_image.study_uid not in self.__studies_by_type[study_type]:
                self.__studies_by_type[study_type][new_image.study_uid] = Study(image=new_image)
            else:
                self.__studies_by_type[study_type][new_image.study_uid].add_image(new_image)

    @property
    def completed(self) -> bool:
        return bool(self.status)

    @property
    def image_count(self) -> int:
        total_count = 0
        for study in self.__studies_by_type.get(PRIMARY_STUDY_KEY, {}).values():
            total_count += study.image_count
        return total_count

    @property
    def duration(self) -> timedelta:
        if self.__duration:
            return self.__duration
        else:
            return datetime.now() - self.__start_time

    @property
    def image_folder(self):
        if isinstance(self.input_study_access, _FileFolderStudyAccess):
            return self.input_study_access.location
        else:
            return self.folder / _IMAGE_FOLDER_NAME

    @property
    def output_folder(self) -> Path:
        if isinstance(self.output_study_access, _FileFolderStudyAccess):
            return self.output_study_access.location
        else:
            return self.folder

    @property
    def primary_study(self) -> Study:
        if self.__studies_by_type[PRIMARY_STUDY_KEY]:
            return next(iter(self.__studies_by_type[PRIMARY_STUDY_KEY].values()))  # only one Primary Study
        return Study()

    @property
    def prior_studies(self) -> List[Study]:
        return list(self.__studies_by_type[PRIOR_STUDY_KEY].values())

    @property
    def selected_image_count(self) -> int:
        return self.primary_study.selected_image_count

    @property
    def selected_series_iterator(self) -> Iterator[Series]:
        return self.primary_study.selected_series

    @property
    def selected_series_list(self) -> List[Series]:
        return self.primary_study.selected_series_list

    @selected_series_list.setter
    def selected_series_list(self, selected_series_list: List[Series]):
        self.primary_study.select_series(*[series.uid for series in selected_series_list])

    @property
    def series_iterator(self) -> Iterator[Series]:
        self.logger.debug("Iterating through series in primary studies")
        for study in self.__studies_by_type[PRIMARY_STUDY_KEY].values():
            self.logger.debug(f"Iterating through study {study.uid}")
            for series in study:
                self.logger.debug(f"Yielding {series.uid}")
                yield series

    @property
    def series_list(self) -> List[Series]:
        return list(self.series_iterator)

    @property
    def status(self):
        if self.__status:
            return self.__status
        else:
            return ""

    @status.setter
    def status(self, _status):
        self.__duration = datetime.now() - self.__start_time
        self.__status = _status
