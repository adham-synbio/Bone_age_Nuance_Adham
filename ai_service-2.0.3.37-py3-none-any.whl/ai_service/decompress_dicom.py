"""
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
try:
    from gdcm import DataElement, Image, ImageReader, ImageWriter, Tag, VL
except ModuleNotFoundError:
    pass
from sys import argv, exit


def decompress_image(images):
    for i in range(0, len(images), 2):
        try:
            input_image = images[i]
            output_image = images[i + 1]

            reader = ImageReader()
            reader.SetFileName(input_image)
            if not reader.Read():
                if __name__ == "__main__":
                    exit(1)
                else:
                    continue
            image = Image()
            image_reader = reader.GetImage()

            image.SetNumberOfDimensions(image_reader.GetNumberOfDimensions())
            image.SetDimension(0, image_reader.GetDimension(0))
            image.SetDimension(1, image_reader.GetDimension(1))

            photometric_interpretation = image_reader.GetPhotometricInterpretation()
            image.SetPhotometricInterpretation(photometric_interpretation)

            pixeldata = DataElement(Tag(0x7fe0, 0x0010))
            buffer = image_reader.GetBuffer()
            pixeldata.SetByteValue(buffer, VL(len(buffer)))
            image.SetDataElement(pixeldata)

            writer = ImageWriter()
            writer.SetFileName(output_image)
            writer.SetFile(reader.GetFile())
            writer.SetImage(image)
            if not writer.Write():
                if __name__ == "__main__":
                    exit(1)
                else:
                    continue
        except:
            if __name__ == "__main__":
                exit(1)
            else:
                continue
    if __name__ == "__main__":
        exit(0)


if __name__ == "__main__":
    decompress_image(argv[1:])
