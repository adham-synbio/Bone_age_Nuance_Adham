#
# Copyright (c) 2020 Nuance Communications, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
import contextlib
import os
import re
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path
from queue import Queue, Empty
from shutil import rmtree
from signal import SIGALRM, SIGTERM, signal, alarm
from threading import Thread
from time import sleep
from traceback import format_exc
from typing import Dict
from urllib.parse import unquote, urlparse

from gunicorn.glogging import CONFIG_DEFAULTS as GLOGGING_CONFIG_DEFAULTS
from pydicom import dcmread
from requests.exceptions import RetryError
from urllib3.exceptions import MaxRetryError

import ai_service.utility
from ai_service.__metadata__ import __description__, __version__
from ai_service.ai_job_processor import AiJob, AiJobProcessor
from ai_service.dicom_image import PRIMARY_STUDY_KEY
from ai_service.environment import KEEP_FILES, LOG_FORMAT, LOG_DATE_FORMAT, REQUEST_PORT, UNDEAD_FILE, SECRET_KEY
from ai_service.logs import get_logger
from ai_service.study_access import _StudyAccess
from ai_service.utility import AiServiceException, AiServiceStatusException, AiServiceNotApplicableException
from ai_service.utility import AiServiceUnlicensedException
from ai_service.utility import _seconds_ago, _Counter, cancel_retries
from result import ResultStatus

_BACKGROUND_THREAD_COUNT = 4
_IMAGE_MILESTONE = 100
_logger = get_logger()
__content_disposition_filename_pattern = re.compile(r'filename\s*=\s*"?(.*?)(?:"|;|$)', re.IGNORECASE)
__content_disposition_filename_star_pattern = re.compile(r'filename\*\s*=(?:\s*(.*)\'\')?\s*"?(.*?)(?:"|;|$)',
                                                         re.IGNORECASE)


def _unhandled_exception_hook(exctype, value, _unused_traceback):  # This should catch exit exceptions (BaseException)
    if str(value).strip():
        message = f"Service is UNHEALTHY!! Unhandled Exception({exctype.__name__}): {value}"
    else:
        message = f"Service is UNHEALTHY!! Unhandled Exception({exctype.__name__})"
    _logger.warning(message)
    _logger.debug(format_exc())
    UNDEAD_FILE.write_text(message)


class AiService:
    """
    AI Service combines partner methods with AI Marketplace's expected behaviors.

    Parameters
    ----------
    ai_job_processor : ai.AiJobProcessor
        An object that provides partner functionality
    """

    ai_application = None
    ai_job_processor = AiJobProcessor

    ready = False

    def __init__(self, ai_job_processor: AiJobProcessor.__class__):
        # This hook is only added when we initiate the service
        sys.excepthook = _unhandled_exception_hook

        # We assume this is the class (not an instance)
        self.ai_job_processor = ai_job_processor

        AiJob.partner_name = self.ai_job_processor.partner_name
        AiJob.service_name = self.ai_job_processor.service_name
        _StudyAccess.partner_name = self.ai_job_processor.partner_name
        _StudyAccess.service_name = self.ai_job_processor.service_name

        _logger.info(f"Starting {self.ai_job_processor.partner_name} {self.ai_job_processor.service_name} "
                     f"{self.ai_job_processor.version} using {__description__} {__version__}")
        try:
            UNDEAD_FILE.unlink()
        except FileNotFoundError:
            pass

    def check_liveness(self) -> bool:
        return self.ai_job_processor.check_liveness()

    def process_job(self, job: AiJob):
        """
        Parameters
        ----------
        job : ai_service.utility.AiJob

        Returns
        -------
        None
        """
        # Create a job processor for this job, it is assumed that jobs will not run concurrently
        job_processor = self.ai_job_processor(job)
        with contextlib.redirect_stdout(job_processor.log_writer), \
                contextlib.redirect_stderr(job_processor.error_log_writer):
            try:
                if SECRET_KEY:
                    if job_processor.authorize():
                        job_processor.logger.debug("Authorized")
                    else:
                        exception_message = f"Authorization '{job_processor.ai_job.authorization}' " \
                                            f"did not match service secret key"
                        job_processor.logger.warning(exception_message)
                        raise AiServiceException(exception_message)

                job_processor.initialize()
                if not job_processor.check_license():
                    raise AiServiceUnlicensedException("AIM Service license is invalid")

                # Prepare the job processor's job using the job processor's image filter
                prepare(job_processor)
                # Check for DICOM images
                if job_processor.ai_job.image_count:
                    job_processor.logger.info("Setting Primary Study Attributes...")
                    job_processor.ai_job.primary_study.attributes.update(
                        job_processor.ai_job.input_study_access.get_attributes(job_processor.ai_job.primary_study.uid))
                    job_processor.logger.debug(f"Study {job_processor.ai_job.primary_study.uid} Attributes set!")
                    job_processor.logger.info("Setting Primary Study's Series Attributes...")
                    for series in job_processor.ai_job.primary_study.series:
                        series.attributes.update(job_processor.ai_job.input_study_access.get_attributes(
                            job_processor.ai_job.primary_study.uid, series_uid=series.uid
                        ))
                        job_processor.logger.debug(f"Study {series.uid} Attributes set!")

                    job_processor.logger.info("Setting Prior Studies Attributes...")
                    for prior_study in job_processor.ai_job.prior_studies:
                        job_processor.logger.info(f"Setting Study {prior_study.uid} Attributes...")
                        prior_study.attributes.update(
                            job_processor.ai_job.input_study_access.get_attributes(prior_study.uid)
                        )
                        job_processor.logger.debug(f"Study {prior_study.uid} Attributes set!")
                        for series in prior_study.series:
                            job_processor.logger.info(f"Setting {series.uid} Series Attributes...")
                            series.attributes.update(job_processor.ai_job.input_study_access.get_attributes(
                                job_processor.ai_job.primary_study.uid, series_uid=series.uid)
                            )
                            job_processor.logger.debug(f"Study {series.uid} Attributes set!")

                    job_processor.ai_job.primary_study.attributes.update(
                        job_processor.ai_job.input_study_access.get_attributes(job_processor.ai_job.primary_study.uid)
                    )
                    job_processor.logger.debug("All Study and Series Attributes set")
                    job_processor.logger.info("Selecting Series...")
                    job_processor.ai_job.primary_study.select_series(series_list=job_processor.select_series(
                        job_processor.ai_job.primary_study.series_list)
                    )
                    for prior_study in job_processor.ai_job.prior_studies:
                        job_processor.logger.debug(f"Selecting series in prior study: {prior_study.uid}")
                        prior_study.select_series(
                            series_list=job_processor.select_prior_series(prior_study.series_list)
                        )
                        noun = "image" if prior_study.selected_image_count == 1 else "images"
                        job_processor.logger.debug(f"Prior Series Selected ({len(prior_study.selected_series_list)} "
                                                   f"series with {prior_study.selected_image_count} {noun})")
                    if not job.selected_image_count:
                        raise AiServiceNotApplicableException("No DICOM images selected for processing")
                    else:
                        noun = "image" if job_processor.ai_job.selected_image_count == 1 else "images"
                        job_processor.logger.info(f"Series Selected ({len(job_processor.ai_job.selected_series_list)} "
                                                  f"series with {job_processor.ai_job.selected_image_count} {noun}), "
                                                  f"processing study")
                    job_processor.process_study()
                    job_processor.logger.info(f"Processed AI Job {job_processor.ai_job.transaction_id} "
                                              f"in {job_processor.ai_job.duration.total_seconds()} seconds")
                    job_processor.set_transaction_status()
                else:
                    raise AiServiceNotApplicableException("No DICOM images available for processing")
            except AiServiceStatusException as status_exception:
                job_processor.logger.warning(status_exception)
                job_processor.set_transaction_status(status=status_exception.status, reason=status_exception.reason)
            except Exception as e:
                try:
                    job_processor.logger.warning(e)
                    job_processor.set_transaction_status(status=ResultStatus.ANALYSIS_FAILED, reason=str(e))
                except UnboundLocalError:
                    job_processor.logger.warning(e)
            finally:
                if not KEEP_FILES:
                    job_processor.logger.debug(f"Cleaning {job.folder}")
                    rmtree(job.folder)  # Cleanup
                    job_processor.logger.info(f"Cleaned {job.folder}")
                else:
                    job_processor.logger.debug(f"NOT cleaning {job.folder}")
            try:
                job_processor.logger.debug("Tearing down Job Processor")
                job_processor.teardown()
                job_processor.logger.debug("Job Processor torn down")
            except UnboundLocalError:
                pass

    @staticmethod
    def _handle_sigalarm(signum, frame):
        _logger.info("Shutting down")
        _logger.debug(f"{signum}: {frame}")
        exit(0)

    @staticmethod
    def _handle_sigterm(signum, frame):
        _logger.info("Received SIGTERM")
        cancel_retries()
        _logger.debug(f"{signum}: {frame}")

    def __actually_shutdown(self):
        while self.ai_job_processor.ai_jobs:
            _logger.info("Waiting 15 seconds for AI Jobs to complete")
            sleep(15)
        _logger.info("Shutdown in 15 seconds")
        alarm(15)

    def shutdown(self):
        self.ai_job_processor.shutdown()
        threading.Thread(target=self.__actually_shutdown, daemon=True).start()
        try:
            self.ai_application.shutdown()
        except AttributeError:
            pass

    def start(self):
        """Start the AI Service"""
        # Localize imports to reduce unexpected behavior
        import ai_service.controller
        from ai_service.application import AiServiceGunicornApplication

        # ai_service.controller cannot import values from ai_service.service
        ai_service.controller.ai_service = self
        _logger.debug("Preparing to catch SIGTERM")
        signal(SIGTERM, AiService._handle_sigterm)
        signal(SIGALRM, AiService._handle_sigalarm)
        _logger.debug("Updating umask to 0000 to make created files globally accessible")
        os.umask(0o0000)
        # Update Gunicorn's logging configuration in order to prevent having two different logging formats
        GLOGGING_CONFIG_DEFAULTS["loggers"]["gunicorn.error"]["propagate"] = False  # Prevents double logging
        GLOGGING_CONFIG_DEFAULTS["loggers"]["gunicorn.access"]["propagate"] = False  # Prevents double logging
        GLOGGING_CONFIG_DEFAULTS["formatters"]["generic"]["format"] = LOG_FORMAT
        GLOGGING_CONFIG_DEFAULTS["formatters"]["generic"]["datefmt"] = LOG_DATE_FORMAT

        gunicorn_configuration = {
            "bind": f"0.0.0.0:{REQUEST_PORT}",
            "logconfig_dict": GLOGGING_CONFIG_DEFAULTS,
            "post_fork": self.post_fork,
            # The number of worker threads for handling requests. Run each worker with the specified number of threads.
            "threads": 3,
            # Workers silent for more than this many seconds are killed and restarted. Value is a positive number or 0.
            # Setting it to 0 has the effect of infinite timeouts by disabling timeouts for all workers entirely.
            "timeout": 0,
            "workers": 1,  # Single process
        }
        if Path("/dev/shm").exists():
            gunicorn_configuration["worker_temp_dir"] = "/dev/shm"
        self.ai_application = AiServiceGunicornApplication(gunicorn_configuration)
        self.ai_application.start()

    def post_fork(self, _unused_server, _unused_worker):
        self.ai_job_processor.initialize_class()
        self.ready = True


def prepare(processor: AiJobProcessor):
    """
    Parameters
    ----------
    processor : AiJobProcessor
        Object that can evaluate images to decide if they are included in the study.

    Returns
    -------
    None
    """
    processor.ai_job.logger.info(processor.ai_job.input_study_access.access_type)
    download_queue = Queue()
    previous_study_type = ""
    previous_study_type_count = 0
    filter_counter = _Counter()

    processor.ai_job.logger.debug("Preparing DICOM instances")
    for study_type, next_instance in processor.ai_job.input_study_access:
        processor.ai_job.logger.debug(f"{study_type}: {next_instance}")
        if study_type != previous_study_type:  # This triggers downloads to drain the queue
            if previous_study_type_count:
                if not download_queue.empty():
                    # Configure and start the next downloads
                    __start_download_threads(previous_study_type_count, processor, download_queue,
                                             processor.ai_job.input_study_access.headers, previous_study_type,
                                             filter_counter)
            previous_study_type = study_type
            previous_study_type_count = processor.ai_job.input_study_access.source_count
            filter_counter = _Counter()
        if Path(next_instance).exists():
            with dcmread(next_instance, defer_size=32) as open_instance:
                if processor.filter_image(open_instance):
                    processor.ai_job.add_image(next_instance, study_type=study_type)
                else:
                    processor.ai_job.logger.info(f"Filtered {next_instance}")
                    filter_counter += 1
        else:
            download_queue.put(next_instance)
    if not download_queue.empty():
        __start_download_threads(previous_study_type_count, processor, download_queue,
                                 processor.ai_job.input_study_access.headers, previous_study_type, filter_counter)
    # Do we need to Collate / Clean-up studies?  Only if a partner starts using DICOM Web and complains


def __start_download_threads(count: int, processor: AiJobProcessor, download_queue: Queue, headers: Dict,
                             study_type: str, filter_counter: _Counter):
    if not download_queue.empty():
        start_time = datetime.now()
        download_counter = _Counter()
        # Forces download threads to yield so that the more disk intensive decompression can start
        decompress_queue = Queue(_IMAGE_MILESTONE // _BACKGROUND_THREAD_COUNT)
        decompress_counter = _Counter()
        download_arguments = [
            count, processor.ai_job, download_queue, decompress_queue, download_counter, filter_counter, processor,
            headers, study_type
        ]
        decompress_arguments = [
            count, processor.ai_job, download_queue, decompress_queue, decompress_counter, filter_counter, study_type
        ]
        for i in range(_BACKGROUND_THREAD_COUNT):
            Thread(name=f"Decompressor-{i}", target=__decompress, args=decompress_arguments, daemon=True).start()
            Thread(name=f"Downloader-{i}", target=__download, args=download_arguments, daemon=True).start()

        __download(*download_arguments)  # help with downloads
        download_queue.join()  # Wait for all threads to finish downloading
        # log results of previous study type
        processor.ai_job.logger.info(f"Downloaded {download_counter}/{count} {study_type} DICOM images")

        __decompress(*decompress_arguments)  # help with decompressing
        decompress_queue.join()  # Wait for all threads to finish decompressing
        processor.ai_job.logger.info(f"Decompressed {decompress_counter}/{count} {study_type} "
                                     f"DICOM images ({filter_counter} filtered)")

        processor.ai_job.logger.info(f"All {study_type} DICOM images downloaded and decompressed "
                                     f"in {_seconds_ago(start_time)} seconds")
    else:
        processor.ai_job.logger.info(f"{filter_counter}/{count} DICOM images filtered")


def __download(total: int, ai_job: AiJob, download_queue: Queue, decompress_queue: Queue, downloaded: _Counter,
               filtered: _Counter, processor: AiJobProcessor, headers: Dict = None,
               study_type: str = PRIMARY_STUDY_KEY):
    """Downloads DICOM images necessary for a study."""
    if headers is None:
        headers = {}
    ai_job.logger.debug(f"Download Headers will combine {ai_service.utility.session.headers} and {headers}")
    while not download_queue.empty():
        try:
            uri = download_queue.get(timeout=1)
            # get the filename and put it in the image folder
            filename = unquote(urlparse(uri).path)
            image = ai_job.image_folder / study_type / Path(filename).name
            try:
                ai_job.logger.debug(f"Downloading {filename} from {uri}")
                try:
                    with ai_service.utility.session.get(uri, stream=True, headers=headers) as response:
                        ai_job.logger.debug(f"Image Source URL: {response.request.url}")
                        ai_job.logger.debug(f"Image Source Headers: {response.request.headers}")
                        ai_job.logger.debug(f"Image Source Response Headers: {response.headers}")
                        # Extract filename from Content-Disposition
                        # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Disposition
                        # The filename is always optional and must not be used blindly by the application:
                        # path information should be stripped
                        # and conversion to the server file system rules should be done.
                        # The parameters "filename" and "filename*" differ only in that "filename*" uses the encoding
                        # defined in RFC 5987. When both "filename" and "filename*" are present in a single header
                        # field value, "filename*" is preferred over "filename" when both are understood.
                        content_disposition = response.headers.get("Content-Disposition", "")

                        filename_star_match = __content_disposition_filename_star_pattern.search(content_disposition)
                        if filename_star_match:
                            filename = unquote(filename_star_match.group(2), filename_star_match.group(1)).strip()
                        else:
                            filename_match = __content_disposition_filename_pattern.search(content_disposition)
                            if filename_match:
                                filename = filename_match.group(1).strip()

                        image = image.parent / Path(filename).name
                        image.parent.mkdir(parents=True, exist_ok=True)

                        # Always download a fresh copy
                        try:
                            # Using "image.unlink(missing_ok=True)" instead of try/catch restricts us to Python 3.8
                            image.unlink()
                        except FileNotFoundError:
                            pass
                        if response.ok and not image.exists():
                            image.write_bytes(response.content)
                except RetryError as e:
                    ai_job.logger.warning(e)
                except (ConnectionError, MaxRetryError, TimeoutError):
                    ai_job.logger.warning(f"Could not download {image}, all retries exhausted")
                if image.exists():
                    downloaded += 1
                    if downloaded % _IMAGE_MILESTONE == 0:
                        ai_job.logger.info(f"Downloaded {downloaded}/{total} DICOM images")
                    with dcmread(image, defer_size=32) as open_image:
                        keep_image = processor.filter_image(open_image)
                        study_uid = open_image.get("StudyInstanceUID", study_type)
                    if keep_image:
                        new_image = ai_job.image_folder / study_uid / image.name
                        new_image.parent.mkdir(parents=True, exist_ok=True)
                        image.rename(new_image)
                        if decompress_queue:
                            decompress_queue.put(str(new_image))
                        else:
                            ai_job.add_image(new_image, study_type=study_type)
                    else:
                        ai_job.logger.info(f"Filtered {image}")
                        filtered += 1
                        image.unlink()
                else:
                    raise AiServiceException(f"Could not download {image}")
            finally:
                # prevent hanging jobs when downloads fail
                download_queue.task_done()
        except Empty:
            pass


def __decompress(total: int, ai_job: AiJob, download_queue: Queue, decompress_queue: Queue, decompressed: _Counter,
                 filtered: _Counter, study_type: str):
    """Decompresses DICOM images."""
    while not download_queue.empty() or not decompress_queue.empty():
        try:
            image = decompress_queue.get(timeout=1)
            image_path = Path(image)
            decompressed_image = image_path.parent / "decompressed" / image_path.name
            decompressed_image.parent.mkdir(parents=True, exist_ok=True)
            try:
                #  Open for decompression, then close again so that the pixel data is not held in memory
                ai_job.logger.debug(f"Decompressing {image}")
                # Only load 32 bytes, lazy load the rest
                with dcmread(image, defer_size=32) as open_image:
                    try:
                        try:
                            open_image.decompress()
                            open_image.save_as(str(decompressed_image))
                        except RuntimeError as runtime_error:
                            try:
                                ai_job.logger.debug("Could not decompress with Python 3, trying Python 2")
                                ai_job.logger.debug(runtime_error)
                                #  Some containers use gdcm-python instead of gdcm-python3
                                import ai_service.decompress_dicom as decompress_dicom
                                subprocess.run(["python", decompress_dicom.__file__, image, decompressed_image])
                            except FileNotFoundError:
                                raise runtime_error
                        decompressed_image.replace(image)
                        decompressed += 1
                        if decompressed % _IMAGE_MILESTONE == 0:
                            ai_job.logger.info(f"Decompressed {decompressed}/{total} DICOM images "
                                               f"({filtered} filtered)")
                    except FileNotFoundError:
                        ai_job.logger.debug(f"Did not decompress {image}")
                    except RuntimeError as reason:
                        # The stack trace is not too useful here, but the missing requirements are.
                        raise AiServiceException(f"Could not decompress {image}. {reason}")
                    ai_job.add_image(dcmread(image, defer_size=32), study_type=study_type)
            finally:
                # prevent hanging jobs when decompression fails
                decompress_queue.task_done()
        except Empty:
            pass
