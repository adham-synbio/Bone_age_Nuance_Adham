"""
Copyright (c) 2021 Nuance Communications, Inc

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
from os import PathLike
from pathlib import Path
from threading import RLock  # a re-entrant lock allows the same thread to lock the lock multiple times
from typing import Iterator, List, Union, Dict, Set, Sized, Iterable, Hashable, Optional

import numpy
import pydicom.uid
from pydicom import dcmread, Dataset, FileDataset

from ai_service.logs import get_logger

logger = get_logger("dicom_image")

PRIMARY_STUDY_KEY = "primary"
PRIOR_STUDY_KEY = "prior"


def sort_images(images: List[Union[str, Dataset]]):
    image_sorter = ImageSorter(images[0])
    images.sort(key=image_sorter)


class Image(Hashable):
    """
    Wrapper class for DICOM images.
    This makes uids easily accessible and streamlines opening the image file.
    """
    # Images are collected by filename so that open images do not remain open in memory
    def __init__(self, image: Union[str, FileDataset, Path, PathLike] = None, uid: str = "", series_uid: str = "", study_uid: str = ""):
        """
        Parameters
        ----------
        image: Union[str, FileDataset, Path, PathLike]
            The DICOM image to be represented.  May be either a file location or an open Dataset.
        uid: str
            The SOPInstanceUID of this image.
        series_uid: str
            The SeriesInstanceUID of this image.
        study_uid: str
            The StudyInstanceUID of this image.
        """
        if image:
            if not isinstance(image, FileDataset):
                if not isinstance(image, str):
                    image = str(image)
                image = dcmread(image, defer_size=32)
            self.__filename = image.filename
            self.__series_uid = image.SeriesInstanceUID
            self.__study_uid = image.StudyInstanceUID
            self.__uid = image.SOPInstanceUID
        else:
            self.__filename = None
            self.__series_uid = series_uid
            self.__study_uid = study_uid
            self.__uid = uid

    def __eq__(self, other):
        return isinstance(other, self.__class__) and hash(self) == hash(other)

    def __hash__(self):
        if self.uid:
            return hash(self.uid)
        else:
            return hash(self.filename)

    def __str__(self):
        return f"Instance UID: {self.uid}, Series UID: {self.series_uid}, Study UID: {self.study_uid}, " \
               f"File: {self.filename}"

    @property
    def filename(self) -> str:
        return self.__filename

    @property
    def series_uid(self) -> str:
        return self.__series_uid

    @property
    def study_uid(self) -> str:
        return self.__study_uid

    @property
    def uid(self) -> str:
        return self.__uid

    @property
    def orientation(self) -> Optional[str]:
        try:
            instance = self.open()
            image_orientation = instance.get("ImageOrientationPatient")
            if image_orientation is not None:
                normal = numpy.cross(image_orientation[:3], image_orientation[3:])
                if numpy.absolute(1 - numpy.absolute(normal.dot([1, 0, 0]))) < .0001:
                    return "SAGITTAL"
                elif numpy.absolute(1 - numpy.absolute(normal.dot([0, 1, 0]))) < .0001:
                    return "CORONAL"
                elif numpy.absolute(1 - numpy.absolute(normal.dot([0, 0, 1]))) < .0001:
                    return "AXIAL"
            return None
        except ValueError:
            return None

    def open(self) -> FileDataset:
        """
        Open the file that backs this Image and return the Dataset that represents it.
        """
        if self.filename:
            with dcmread(self.filename, defer_size=32) as open_image:
                return open_image
        else:
            logger.warning(f"DICOM has no backing file: {self} ")


class ImageSorter:
    """
    Sorts DICOM images.

    This should be instantiated using an image from the study to be sorted.
    It operates on the assumption that all the images in a study will have similar composition
    """

    def __init__(self, image: Union[Dataset, Image, Path, PathLike, str]):
        if not isinstance(image, Image):
            image = Image(image)
        image = image.open()

        # images with a SharedFunctionalGroupsSequence will need to be sorted by time when position doesn't change,
        # this is not currently useful
        try:
            orientation = image.ImageOrientationPatient
            # | A B C |
            # | D E F | to [ BF - CE, CD - AF, AE - BD ]
            self.normals = [
                orientation[1] * orientation[5] - orientation[2] * orientation[4],
                orientation[2] * orientation[3] - orientation[0] * orientation[5],
                orientation[0] * orientation[4] - orientation[1] * orientation[3],
            ]
        except (AttributeError, IndexError, TypeError):
            # AttributeError should not be raised, ImageOrientationPatient is type 2
            # http://dicom.nema.org/medical/dicom/current/output/html/part05.html#sect_7.4.3
            # IndexError will occur if the ImageOrientationPatient is ''
            # TypeError will occur if ImageOrientationPatient is 'Unknown'
            logger.info("Images do not contain ImageOrientationPatient (0020,0037),"
                        " images will be sorted by InstanceNumber")

    def __call__(self, image: Union[Dataset, Image, Path, PathLike, str]):
        if not isinstance(image, Image):
            image = Image(image)
        open_image = image.open()

        try:
            # distance will raise AttributeError if self.normals does not exist
            # AcquisitionTime is used to differentiate between equidistant images,
            # it will be present in multi-image series
            return self.distance(open_image), open_image.get("AcquisitionTime", 1)
        except AttributeError:
            if open_image:
                return open_image.InstanceNumber  # Instance number will default to 0 if it does not exist
            else:
                return hash(image)

    def distance(self, image: Dataset):
        """
        Determine the distance from the first slice in a series, this is STRONGLY preferred as these values cannot be
        edited without changing the meaning of the image
        More detail available here: https://itk.org/pipermail/insight-users/2003-September/004762.html

        The x-axis is increasing to the left hand side of the patient.
        The y-axis is increasing to the posterior side of the patient.
        The z-axis is increasing toward the head of the patient.

        This sorts images from the patient's left little toe to the right ear (roughly)
        """
        # Combined distance by multiplying each position's directional cosine's normal by that position's coordinate
        return sum([self.normals[i] * image.ImagePositionPatient[i] for i in range(3)])

    @staticmethod
    def position(image: Union[Dataset, Image, Path, PathLike, str]):
        """
        Sort images by determining the combined directional cosines for rows and columns,
        then returning the position based upon the values of those cosines

        This may be faster than Distance

        https://www.medicalconnections.co.uk/kb/Sorting-Images/
        """
        if not isinstance(image, Image):
            image = Image(image)
        image = image.open()

        # Obtain the combined directional cosines by summing the square of the row and column cosines
        directional_cosines = []
        for i in range(3):
            directional_cosines.append(image.ImageOrientationPatient[i] ** 2 + image.ImageOrientationPatient[i+3] ** 2)

        if directional_cosines[0] <= directional_cosines[1] and directional_cosines[0] <= directional_cosines[2]:
            return image.ImagePositionPatient[0]
        elif directional_cosines[1] <= directional_cosines[0] and directional_cosines[1] <= directional_cosines[2]:
            return image.ImagePositionPatient[1]
        else:
            return image.ImagePositionPatient[2]


class Series(Hashable, Iterable, Sized):
    """
    Wrapper class for a series of DICOM images.
    This makes uids easily accessible and streamlines opening the image files.
    """

    def __init__(self, image: Union[str, FileDataset, Image, None, Path, PathLike] = None):
        """
        Parameters
        ----------
        image: Union[str, FileDataset, Path, PathLike]
            The first DICOM image to be represented by this series.  May be either a file location or an open Dataset.
        """
        self.__lock = RLock()
        self.__key: Optional[ImageSorter] = None
        self.__images: Dict[str, Image] = {}
        self.attributes = dict()
        if image:
            if not isinstance(image, Image):
                image = Image(image)
            self.__images[image.uid] = image
        self.series: Dict[str, Set[Image]] = {}
        self.__sorted_images: List[Image] = []

    def __eq__(self, other):
        return isinstance(other, self.__class__) and hash(self) == hash(other)

    def __getitem__(self, item):
        if isinstance(item, str):
            return self.__images[item]
        else:
            return self.images[item]

    def __hash__(self):
        return hash(self.uid)

    def __iter__(self) -> Iterator[Dataset]:
        return self.open()

    def __len__(self):
        return len(self.__images)

    @property
    def image(self) -> Optional[FileDataset]:
        with self.__lock:
            try:
                image, *_unused = self.__images.values()
                return image.open()
            except ValueError:
                return None

    @property
    def images(self) -> List[Image]:
        with self.__lock:
            # Cache the sorted images
            if not self.__sorted_images:
                if len(self.__images) > 1:
                    if not self.key:
                        image, *_unused = self.__images.values()  # Unpack the set to assign one element to image
                        self.key = ImageSorter(image)
                    self.__sorted_images = sorted(self.__images.values(), key=self.key)
                else:
                    self.__sorted_images = list(self.__images.values())
            return self.__sorted_images

    @property
    def key(self) -> Optional[ImageSorter]:
        with self.__lock:
            return self.__key

    @key.setter
    def key(self, key: Union[ImageSorter]):
        with self.__lock:
            self.__sorted_images.clear()
            self.__key = key

    @property
    def orientation(self) -> Optional[str]:
        with self.__lock:
            try:
                return next(iter(self.__images.values())).orientation
            except (StopIteration, ValueError):
                return None

    @property
    def study_uid(self) -> str:
        with self.__lock:
            try:
                return next(iter(self.__images.values())).study_uid
            except ValueError:
                return ""

    @property
    def uid(self) -> str:
        with self.__lock:
            try:
                return next(iter(self.__images.values())).series_uid
            except (StopIteration, ValueError):
                return ""

    def add_image(self, image: Union[str, FileDataset, Image, Path, PathLike]):
        """
        Add a DICOM image to this series.

        Parameters
        ----------
        image: Union[str, FileDataset, Path, PathLike]
            The DICOM image to be added.
            This image will only be added if its SeriesInstanceUID matches that of this series.
        """
        with self.__lock:
            if not isinstance(image, Image):
                image = Image(image)
            if len(self):
                # Validate series_uid
                if self.uid == image.series_uid and self.study_uid == image.study_uid:
                    self.__images[image.uid] = image
                    self.__sorted_images.clear()
            else:
                self.__images[image.uid] = image

    def open(self) -> Iterator[Dataset]:
        """
        Generate a stream of Datasets representing the DICOM image files that back this series.
        """
        with self.__lock:
            for image in self.images:
                if image.filename:
                    yield image.open()
                else:
                    logger.warning(f"DICOM image has no backing file: {image}")

    def remove_image(self, image: Union[str, FileDataset, Image, Path, PathLike]):
        with self.__lock:
            if not isinstance(image, Image):
                image = Image(image)
            self.__images.pop(image.uid)
            self.__sorted_images.clear()


class Study(Hashable, Iterable, Sized):
    """
    Wrapper class for DICOM images based study.
    This makes uids easily accessible and streamlines opening the image file.
    """

    def __init__(self, image: Union[str, FileDataset, Image, None, Path, PathLike] = None):
        """
        Parameters
        ----------
        image: Union[str, FileDataset, Path, PathLike]
            The first DICOM image to be represented by this study.  May be either a file location or an open Dataset.
        """
        self.__all_series: Dict[str, Series] = {}
        self.__folder = None
        self.__lock = RLock()
        self.__selected_series: Set[str] = set()
        self.attributes = dict()
        if image:
            self.add_image(image)

    def __eq__(self, other):
        return isinstance(other, self.__class__) and hash(self) == hash(other) and len(self) == len(other)

    def __getitem__(self, item):
        if isinstance(item, str):
            return self.__all_series[item]
        else:
            return self.series_list[item]

    def __hash__(self):
        return hash(self.uid)

    def __contains__(self, item):
        if isinstance(item, Series):
            return item in self.__all_series.values()
        elif isinstance(item, str):
            return item in self.__all_series
        else:
            return False

    def __iter__(self) -> Iterator[Series]:
        return self.selected_series

    def __len__(self) -> int:
        return self.selected_image_count

    @property
    def folder(self) -> Optional[Path]:
        if self.__folder is None:
            with self.__lock:
                if self.__folder is None:
                    for series in self.series:
                        image = series.image
                        if image:  # Empty series will not have any images
                            self.__folder = Path(image.filename).parent
                            break
        return self.__folder

    @property
    def image_count(self) -> int:
        total_count = 0
        for series in self.series:
            total_count += len(series)
        return total_count

    @property
    def series(self) -> Iterator[Series]:
        for series in self.__all_series.values():
            yield series

    @property
    def series_list(self) -> List[Series]:
        return list(self.series)

    @property
    def selected_image_count(self) -> int:
        total_count = 0
        for series in self.selected_series:
            total_count += len(series)
        return total_count

    @property
    def selected_series(self) -> Iterator[Series]:
        for series in self.__all_series.values():
            if series.uid in self.__selected_series:
                yield series

    @property
    def selected_series_list(self) -> List[Series]:
        return list(self.selected_series)

    @property
    def uid(self) -> str:
        with self.__lock:
            for series in self.series:
                if series.study_uid:  # Empty series will not have a study_uid
                    return series.study_uid
            return ""

    def add_image(self, image: Union[str, FileDataset, Image, Path, PathLike]):
        """
        Add a DICOM image to this study.

        Parameters
        ----------
        image: Union[str, FileDataset, Path, PathLike]
            The DICOM image to be added.
            This image will only be added if it's StudyInstanceUID matches that of the study.
        """
        with self.__lock:
            if not isinstance(image, Image):
                image = Image(image)
            if len(self.__all_series):  # Check to see if any series contain any images
                try:
                    # image checking will be done by Series
                    self.__all_series[image.series_uid].add_image(image)
                except KeyError:
                    if self.uid == image.study_uid:
                        self.add_series(Series(image))
            else:
                self.add_series(Series(image))

    def add_series(self, series: Series):
        """
        Add a Series of DICOM images to this Study.

        Parameters
        ----------
        series: Series
            Series to be added.
        """
        with self.__lock:
            self.__all_series[series.uid] = series

    def deselect_series(self, *series_uid: str, series_list: Optional[List[Series]] = None):
        for uid in series_uid:
            self.__selected_series.remove(uid)
        if series_list is not None:
            for series in series_list:
                self.__selected_series.remove(series.uid)

    def select_series(self, *series_uid: str, series_list: Optional[List[Series]] = None):
        self.__selected_series.update(series_uid)
        if series_list is not None:
            self.__selected_series.update([series.uid for series in series_list])

    def series_by_uid(self, series_uid: str) -> Optional[Series]:
        return self.__all_series.get(series_uid, None)


def related_uid(uid: str) -> str:
    try:
        return pydicom.uid.generate_uid(uid[:uid.rindex(".") + 1])
    except ValueError:
        return pydicom.uid.generate_uid(uid[:62] + ".")
