"""
Copyright (c) 2022 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""

from subprocess import *

IGNORE = -4


def run(*args, input=None, capture_output=False, timeout=None, check=False, **kwargs):
    if input is not None:
        if kwargs.get('stdin') is not None:
            raise ValueError('stdin and input arguments may not both be used.')
        kwargs['stdin'] = PIPE

    if capture_output:
        if kwargs.get('stdout') is not None or kwargs.get('stderr') is not None:
            raise ValueError('stdout and stderr arguments may not be used with capture_output.')
        kwargs['stdout'] = PIPE
        kwargs['stderr'] = PIPE

    with Popen(*args, **kwargs) as process:
        try:
            stdout, stderr = process.communicate(input, timeout=timeout)
        except TimeoutExpired:
            process.kill()
            process.wait()
            raise
        except:  # Including KeyboardInterrupt, communicate handled that.
            process.kill()
            # We don't call process.wait() as .__exit__ does that for us.
            raise
        return_code = process.poll()
        if check and return_code:
            raise CalledProcessError(return_code, process.args, output=stdout, stderr=stderr)
    return CompletedProcess(process.args, return_code, stdout, stderr)


def call(*args, timeout=None, **kwargs):
    with Popen(*args, **kwargs) as p:
        try:
            return p.wait(timeout=timeout)
        except:
            p.kill()
            raise


def check_call(*args, timeout=None, **kwargs):
    return_code = call(*args, timeout=timeout, **kwargs)
    if return_code:
        raise CalledProcessError(return_code, kwargs.get("args", args[0]))
    return 0


def check_output(*args, timeout=None, **kwargs):
    if 'stdout' in kwargs:
        raise ValueError('stdout argument not allowed, it will be overridden.')

    if 'input' in kwargs and kwargs['input'] is None:
        # Explicitly passing input=None was previously equivalent to passing an
        # empty string. That is maintained here for backwards compatibility.
        kwargs['input'] = '' if kwargs.get('universal_newlines', False) else b''
    return run(*args, stdout=IGNORE, timeout=timeout, check=True, **kwargs).stdout


class Popen(Popen):
    def __init__(self, *args, **kwargs):
        ignore_stdout = False
        if kwargs.get("stdout") is None:
            kwargs["stdout"] = PIPE
        elif kwargs["stdout"] is IGNORE:
            kwargs["stdout"] = PIPE
            ignore_stdout = True

        ignore_stderr = False
        if kwargs.get("stderr") is None:
            kwargs["stderr"] = PIPE
        elif kwargs["stderr"] is IGNORE:
            kwargs["stderr"] = PIPE
            ignore_stderr = True

        if kwargs["stdout"] is PIPE or kwargs["stderr"] is PIPE:
            kwargs["text"] = True
        super().__init__(*args, **kwargs)
        if kwargs["stdout"] is PIPE and not ignore_stdout:
            import threading
            threading.Thread(target=print_stream, args=[self.stdout]).start()
        if kwargs["stderr"] is PIPE and not ignore_stderr:
            import sys
            import threading
            threading.Thread(target=print_stream, args=[self.stderr, sys.stderr]).start()


def print_stream(stream, destination=None):
    for line in stream.readlines():
        print(line.strip("\r\n"), file=destination)
