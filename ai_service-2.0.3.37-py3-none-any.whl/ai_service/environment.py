"""

Copyright (c) 2020 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import tempfile
from logging import DEBUG, INFO
from os import environ
from pathlib import Path

# Keys to consolidate and ease configuration
__DEBUG = "DEBUG"
__KEEP_FILES = "KEEP_FILES"
__LOG_DATE_FORMAT = "LOG_DATE_FORMAT"
__LOG_FORMAT = "LOG_FORMAT"
__LOG_INCLUDE_TIMESTAMP = "LOG_TIMESTAMP"
__LOG_FILE_DATE_FORMAT = "LOG_FILE_DATE_FORMAT"
__LOG_FILE_FORMAT = "LOG_FILE_FORMAT"
__LOG_FILE_INCLUDE_TIMESTAMP = "LOG_FILE_TIMESTAMP"
__LOG_TIMESTAMP_FORMAT = "LOG_TIMESTAMP_FORMAT"
__MAX_THREADS_KEY = "maxThreads"
__MIN_FREE_DISK_KEY = "minFreeDiskGB"
__REQUEST_PORT_KEY = "requestPort"
__SECRET_KEY = "secretKey"
__SELF_HOSTED_KEY = "selfHosted"
__SUBSCRIPTION_KEY_KEY = "subscriptionKey"
__TEMP_DIR_KEY = "tempDir"

# False values
__false_values = ["false", "nay", "never", "no", "none", "nope", "not"]

# Default Values
__LOG_DATE_FORMAT_DEFAULT = "%Y-%m-%d %H:%M:%S"
__LOG_FORMAT_DEFAULT = "%(levelname)7s %(message)s"
__LOG_INCLUDE_TIMESTAMP_DEFAULT = False
__LOG_FILE_DATE_FORMAT_DEFAULT = __LOG_DATE_FORMAT_DEFAULT
__LOG_FILE_FORMAT_DEFAULT = "%(levelname)7s %(message)s"
__LOG_FILE_INCLUDE_TIMESTAMP_DEFAULT = True
__LOG_TIMESTAMP_FORMAT_DEFAULT = "[%(asctime)s.%(msecs)03d]"


def __check_boolean_value(value) -> bool:
    try:
        value = float(value)
    except ValueError:
        pass
    return str(value).casefold() not in __false_values if bool(value) else False


# Exported values
GB = 8 * 1024 ** 3
KEEP_FILES = __check_boolean_value(environ.get(__KEEP_FILES, False))
MAX_THREADS = int(environ.get(__MAX_THREADS_KEY, 1))
MIN_FREE_DISK_GB = int(environ.get(__MIN_FREE_DISK_KEY, 0))
REQUEST_PORT = environ.get(__REQUEST_PORT_KEY, "5000")
SECRET_KEY = environ.get(__SECRET_KEY, "")
SELF_HOSTED = __check_boolean_value(environ.get(__SELF_HOSTED_KEY, False))
SUBSCRIPTION_KEY = environ.get(__SUBSCRIPTION_KEY_KEY, "AiSvcTestKey")
TEMP_DIR = Path(environ.get(__TEMP_DIR_KEY, tempfile.gettempdir()))
UNDEAD_FILE = TEMP_DIR / "zombie"

# Exported Logging Values
LOGGING_LEVEL = DEBUG if __check_boolean_value(environ.get(__DEBUG, False)) else INFO
LOG_TIMESTAMP_FORMAT = environ.get(__LOG_TIMESTAMP_FORMAT, __LOG_TIMESTAMP_FORMAT_DEFAULT)
LOG_DATE_FORMAT = environ.get(__LOG_DATE_FORMAT, __LOG_FILE_DATE_FORMAT_DEFAULT)
LOG_FORMAT = environ.get(__LOG_FORMAT, __LOG_FORMAT_DEFAULT)
LOG_INCLUDE_DATE = __check_boolean_value(environ.get(__LOG_INCLUDE_TIMESTAMP, __LOG_INCLUDE_TIMESTAMP_DEFAULT))
LOG_FILE_DATE_FORMAT = environ.get(__LOG_FILE_DATE_FORMAT, __LOG_FILE_DATE_FORMAT_DEFAULT)
LOG_FILE_FORMAT = environ.get(__LOG_FILE_FORMAT, __LOG_FILE_FORMAT_DEFAULT)
if __check_boolean_value(environ.get(__LOG_INCLUDE_TIMESTAMP, __LOG_INCLUDE_TIMESTAMP_DEFAULT)):
    LOG_FORMAT = f"{LOG_TIMESTAMP_FORMAT} {LOG_FORMAT}"
if __check_boolean_value(environ.get(__LOG_FILE_INCLUDE_TIMESTAMP, __LOG_FILE_INCLUDE_TIMESTAMP_DEFAULT)):
    LOG_FILE_FORMAT = f"{LOG_TIMESTAMP_FORMAT} {LOG_FILE_FORMAT}"

# These will be included in individual job configuration
_CONFIGURATION = {}
if MAX_THREADS:
    _CONFIGURATION[__MAX_THREADS_KEY] = MAX_THREADS
if TEMP_DIR:
    _CONFIGURATION[__TEMP_DIR_KEY] = TEMP_DIR
