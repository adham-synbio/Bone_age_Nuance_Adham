"""
Copyright (c) 2020 Nuance Communications, Inc

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
from os import kill
from signal import SIGTERM, SIGINT
import sys

from gunicorn.app.base import BaseApplication
from gunicorn.arbiter import Arbiter

from ai_service.controller import ai_controller
from ai_service.logs import get_logger

_logger = get_logger()


class AiServiceGunicornApplication(BaseApplication):
    _arbiter = None
    """
    Wrapper Class to run our Flask controller via Gunicorn (Green Unicorn).
    https://docs.gunicorn.org/en/stable/custom.html
    """

    def __init__(self, options=None):
        self.options = options or {}
        self.application = ai_controller
        super(AiServiceGunicornApplication, self).__init__()

    def load(self):
        return self.application

    def load_config(self):
        config = {
            key: value
            for key, value in self.options.items()
            if key in self.cfg.settings and value is not None
        }
        for key, value in config.items():
            self.cfg.set(key.lower(), value)

    def start(self):
        try:
            self._arbiter = Arbiter(self)
            self._arbiter.master_name = "ai_service"
            self._arbiter.SIGNALS = [
                _signal for _signal in Arbiter.SIGNALS if _signal is not SIGTERM
            ]
            self._arbiter.run()
        except RuntimeError as e:
            print("\nError: %s\n" % e, file=sys.stderr)
            sys.stderr.flush()
            sys.exit(1)

    def shutdown(self):
        kill(self._arbiter.pid, SIGINT)
