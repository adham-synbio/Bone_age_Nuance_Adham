#!/usr/bin/python3
# Copyright (c) 2021 Nuance Communications, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
import collections.abc
import logging
from pathlib import Path
from threading import Lock
from typing import Iterator, Dict, Collection, Optional, List, Tuple

from urllib3.exceptions import HTTPError, HTTPWarning
from requests.exceptions import RequestException, RequestsWarning

from ai_service import utility
from ai_service.dicom_image import PRIMARY_STUDY_KEY, PRIOR_STUDY_KEY
from ai_service.environment import SUBSCRIPTION_KEY
from ai_service.logs import get_logger
from ai_service.utility import _Document, _mask_keys, DICOM_MIME_TYPE, JSON_MIME_TYPE, AiServiceException
from result import Result, ResultStatus

_ADD_DOCUMENT_PATH = "/results/{RESULT_ID}/documents"
_AIM_TRANSACTION_MANAGER = "AIM_TRANSACTION_MANAGER"
_CONTENT_TYPE_JSON = {"Content-Type": JSON_MIME_TYPE}
_CONTENT_TYPE_FORM = {"Content-Type": "multipart/form-data"}
_CREATE_RESULT_PATH = "/results"
_DICOM_WEB_TYPE = "DICOM_WEB"
_FILE_FOLDER_TYPE = "FILE_FOLDER"

logger = get_logger("study_access")


class _StudyAccess(collections.abc.Iterable):
    partner_name = ""
    service_name = ""
    headers = {}
    location: Optional[Path] = None

    def __iter__(self) -> Iterator[Tuple[str, str]]:
        yield from ()  # empty iterator

    def __new__(cls, transaction_id: int, study_access: Dict, *args, **kwargs):
        # Short circuit so this can be inherited
        if cls != _StudyAccess:
            return object.__new__(cls)
        if study_access["type"] == _AIM_TRANSACTION_MANAGER:
            return _AimTransactionManagerStudyAccess.__new__(_AimTransactionManagerStudyAccess, transaction_id,
                                                             study_access)
        elif study_access["type"] == _DICOM_WEB_TYPE:
            return _DicomWebStudyAccess.__new__(_DicomWebStudyAccess, transaction_id, study_access)
        elif study_access["type"] == _FILE_FOLDER_TYPE:
            return _FileFolderStudyAccess.__new__(_FileFolderStudyAccess, transaction_id, study_access)
        # Defaults to returning itself
        return object.__new__(cls)

    def __init__(self, transaction_id: int, access_type, *args, **kwargs):
        self.access_type = access_type
        self.result_id = 0
        self._sources: Collection = []
        self.source_count = 0
        self.transaction_id = transaction_id
        self.version = 2

    def complete_result(self, status: ResultStatus = ResultStatus.ANALYSIS_COMPLETE, reason: str = "") -> ResultStatus:
        logger.debug(f"Output type {self.access_type} cannot complete results")
        return ResultStatus.ANALYSIS_FAILED

    def get(self, study_uid: str, series_uid: str, image_uid: str) -> str:
        logger.debug(f"No download strategy for output type {self.access_type}")
        return ""

    def get_attributes(self, study_uid: str, series_uid: Optional[str] = None) -> Dict:
        logger.debug(f"Requesting attributes for StudyUID: {study_uid} and SeriesInstanceUID: {series_uid} "
                     f"in {self._sources}")
        return {}

    def put(self, document: _Document):
        logger.debug(f"No upload strategy for {document.file_path.name} for output type {self.access_type}")


class _AimTransactionManagerStudyAccess(_StudyAccess):
    def __init__(self, transaction_id: int, study_access: Dict, *args, sources: Optional[Collection[str]] = None,
                 **kwargs):
        super().__init__(transaction_id, study_access, *args, **kwargs)
        self._sources = set()
        if sources is not None:
            self._sources.update(sources)
        self.__create_result_lock = Lock()
        self.source_count = len(self._sources)
        self.subscription_key = SUBSCRIPTION_KEY
        self.url = study_access["aimTransactionManager"]["url"]

    def __iter__(self):
        for next_instance in self._sources:
            yield PRIMARY_STUDY_KEY, next_instance

    def complete_result(self, status: ResultStatus = ResultStatus.ANALYSIS_COMPLETE, reason: str = "") -> ResultStatus:
        logger.debug(f"Completing a result for AI Job {self.transaction_id}")
        completion_url = self.url
        try:
            status_json = {"status": str(status)}
            if reason and ResultStatus(status) is not ResultStatus.ANALYSIS_COMPLETE:
                status_json["reason"] = reason
            with utility.session.put(
                completion_url,
                headers=_CONTENT_TYPE_JSON,
                json=status_json
            ) as response:
                # Log after building the response, so we have access to the complete headers
                logger.info(f"Sending {status_json['status']} to {response.request.url} "
                            f"with headers {_mask_keys(response.request.headers)}")
                logger.debug(f"Response Headers: {response.headers}")
                if response.ok:
                    response_status = response.json()["status"]
                    logger.debug(f'Status set to "{response_status}"')
                    if "reason" in response.json():
                        logger.debug(f"Reason: {response.json()['reason']}")
                    return response_status
                else:
                    logger.debug(f"Request Failed: {response.status_code} - {response.reason}")
                    raise AiServiceException(f"Could not complete result for transaction {self.transaction_id}")
        except (HTTPError, HTTPWarning, RequestException, RequestsWarning) as e:
            logger.warning(e)
            raise AiServiceException(f"Could not complete result for transaction {e}")

    def __create_result(self):
        if self.result_id == 0:
            with self.__create_result_lock:
                if self.result_id == 0:
                    create_result_url = self.url + _CREATE_RESULT_PATH
                    with utility.session.post(
                        create_result_url,
                        json={
                            "serviceKey": f"{self.partner_name}-{self.service_name}",
                            "resultKey": self.transaction_id,
                            "resultType": "FROM_AI_SERVICE",
                        },
                        headers=_CONTENT_TYPE_JSON,
                    ) as response:
                        # Log after building the response, so we have access to the complete headers
                        logger.info(f'Requesting result from "{response.request.url}" '
                                    f'with headers {_mask_keys(response.request.headers)}')
                        logger.debug(f"Response Headers: {response.headers}")
                        if response.status_code == 201:
                            result_json = response.json()
                            logger.debug(result_json)
                            self.result_id = result_json["id"]
                        else:
                            logger.debug(f"Request Failed: {response.status_code} - {response.reason}")
                            raise AiServiceException(f"Could not create result for transaction {self.transaction_id}")

    def put(self, document: _Document):
        self.__create_result()
        try:
            add_document_url = self.url + _ADD_DOCUMENT_PATH.format(RESULT_ID=self.result_id)
            with utility.session.post(
                    add_document_url,
                    headers={"Ocp-Apim-Subscription-Key": self.subscription_key},
                    data=document.data,
                    files=document.files
            ) as response:
                # Log after building the response, so we have access to the complete headers
                logger.info(f'Adding {document.file_path.name} via "{response.request.url}" '
                            f'with headers {_mask_keys(response.request.headers)}')
                logger.debug(f"Response Headers: {response.headers}")
                if not response or response.status_code != 201:
                    logger.debug(f"Request Status not 201: {response.status_code} - {response.reason}")
                    raise AiServiceException(f"Could not add {document.file_path.name} "
                                             f"to {self.url} ({response.reason})")
        except (HTTPError, HTTPWarning, RequestException, RequestsWarning) as e:
            logger.warning(e)
            raise AiServiceException(f"Could not add {document.file_path.name} to {self.url} ({e})")


class _StudyAccessV2(_StudyAccess):
    def __init__(self, transaction_id: int, study_access: Dict, *args, sources: Optional[List] = None, **kwargs):
        super().__init__(transaction_id, study_access, *args, sources=sources, **kwargs)
        if sources is None:
            self._sources = []
        else:
            self._sources = sources
            for study in self._sources[:1]:
                for series in study.get("series", []):
                    self.source_count += len(series.get("images", []))

    def __iter__(self):
        for study in self._sources[:1]:
            for series in study.get("series", []):
                for image in series.get("images", []):
                    yield PRIMARY_STUDY_KEY, self.get(study["uid"], series["uid"], image)
        self.source_count = 0  # Update the source count to reference the prior studies
        for study in self._sources[1:]:
            for series in study.get("series", []):
                self.source_count += len(series.get("images", []))
        for study in self._sources[1:]:
            for series in study.get("series", []):
                for image in series.get("images", []):
                    yield PRIOR_STUDY_KEY, self.get(study["uid"], series["uid"], image)

    def get_attributes(self, study_uid: str, series_uid: Optional[str] = None) -> Dict:
        for study in self._sources:
            if study.get("uid") == study_uid:
                if series_uid is None:
                    return study.get("attributes", {})
                else:
                    for series in study.get("series", []):
                        if series.get("uid") == series_uid:
                            return series.get("attributes", {})
                    return {}
        return {}


class _DicomWebStudyAccess(_StudyAccessV2):
    def __init__(self, transaction_id: int, study_access: Dict, *args, sources: Optional[List] = None, **kwargs):
        super().__init__(transaction_id, study_access, *args, sources=sources, **kwargs)
        self.url = study_access["dicomWeb"]["url"]
        self.headers = {
            "Authorization": study_access["dicomWeb"]["authToken"],
            "Accept": DICOM_MIME_TYPE,
        }

    def get(self, study_uid: str, series_uid: str, image_uid: str) -> str:
        return f"{self.url}/studies/{study_uid}/series/{series_uid}/instances/{image_uid}"


class _FileFolderStudyAccess(_StudyAccessV2):
    def __init__(self, transaction_id: int, study_access: Dict, *args, sources: Optional[List] = None, **kwargs):
        super().__init__(transaction_id, study_access, *args, sources=sources, **kwargs)
        self.location = Path(study_access["fileFolder"]["location"])
        if logger.level <= logging.DEBUG:
            for f in self.location.rglob("*"):
                if f.is_file():
                    logger.debug(f"Found File: '{f.absolute()}'")
                if f.is_dir():
                    logger.debug(f"Found Folder: '{f.absolute()}'")
        self.result = Result(self.location, f"{self.partner_name}-{self.service_name}-FHIR.json")

    def complete_result(self, status: ResultStatus = ResultStatus.ANALYSIS_COMPLETE, reason: str = "") -> ResultStatus:
        logger.debug(f"Writing result manifest for AI Job {self.transaction_id}")
        self.result.status = status
        if reason and ResultStatus(status) is not ResultStatus.ANALYSIS_COMPLETE:
            self.result.reason = reason
        self.result.write(self.version)
        result_manifest = self.result.result_folder / "resultManifest.json"
        if result_manifest.exists():
            logger.info(f'Wrote manifest file "{result_manifest.absolute()}"')
        else:
            logger.warning(f'Could not write manifest file "{result_manifest.absolute()}"')
        logger.debug(self.result.manifest_v2)
        return status

    def get(self, study_uid: str, series_uid: str, image_uid: str) -> str:
        image_location = (self.location / study_uid / f"{image_uid}.dcm").absolute().as_posix()
        logger.debug(f"Getting Image: {image_location}")
        return image_location

    def put(self, document: _Document):
        self.location.mkdir(parents=True, exist_ok=True)
        destination = (self.location / document.file_path.name).resolve().absolute()
        if destination != document.file_path:
            logger.debug(f"Copying {document} to {destination} (Exists? {document.file_path.exists()})")
            try:
                document.file_path.rename(destination)
            except OSError:
                destination.write_bytes(document.file_path.read_bytes())
            if destination.exists():
                logger.info(f'Copied "{document.file_path.absolute()}" to "{destination.absolute()}"')
            else:
                raise AiServiceException(f'Could not copy "{document.file_path.absolute()}" '
                                         f'to "{destination.absolute()}"')
        self.result.add_artifact(destination, series_uid=document.series_uid, group_code=document.group_code,
                                 content_type=document.document_type, tracking_uids=document.tracking_uids)


UNSET_INPUT_STUDY_ACCESS = _StudyAccess(-1, {"type": "UNSET_INPUT"})
UNSET_OUTPUT_STUDY_ACCESS = _StudyAccess(-1, {"type": "UNSET_OUTPUT"})
