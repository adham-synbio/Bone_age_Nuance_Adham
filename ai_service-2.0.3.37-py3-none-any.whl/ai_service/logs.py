"""

Copyright (c) 2020 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import logging
from io import IOBase
from logging import FileHandler, Formatter
from pathlib import Path
from threading import Lock
from typing import Optional

from ai_service.environment import LOG_FORMAT, LOG_DATE_FORMAT, LOG_FILE_FORMAT, LOG_FILE_DATE_FORMAT, LOGGING_LEVEL

_SEPARATOR_LENGTH = 80
_CHAIN = "=".join(("-" for i in range(_SEPARATOR_LENGTH)))


def get_logger(name: Optional[str] = None):
    if name:
        return _AiServiceLogger(name)
    return _AiServiceLogger.root_logger()


def get_transaction_logger(transaction_id=0):
    """
    Parameters
    ----------
    transaction_id : int
        Transaction ID whose logger is requested

    Returns
    -------
    logger for this transaction
    """
    return get_logger(f"transaction.{transaction_id}")


class _AiServiceLogger:
    __lock = Lock()
    __root_logger: Optional["_AiServiceLogger"] = None

    def __init__(self, name=""):
        if name:
            self.logger = logging.getLogger(f"ai_service.{name}")
        else:
            import sys
            self.logger = logging.getLogger("ai_service")
            self.logger.propagate = False
            self.level = LOGGING_LEVEL
            self.warning(f"Logging initialized, level set to {LOGGING_LEVEL} ({logging.INFO} is INFO, "
                         f"{logging.DEBUG} is DEBUG)")
            handler = logging.StreamHandler(sys.__stdout__)
            handler.setFormatter(Formatter(fmt=LOG_FORMAT, datefmt=LOG_DATE_FORMAT))
            self.add_handler(handler)

    @property
    def level(self):
        return self.logger.getEffectiveLevel()

    @level.setter
    def level(self, level):
        self.logger.setLevel(level)

    @classmethod
    def root_logger(cls):
        if cls.__root_logger is None:
            with cls.__lock:
                if cls.__root_logger is None:
                    cls.__root_logger = _AiServiceLogger()
        return cls.__root_logger

    def debug(self, message, *args, **kwargs):
        self.logger.debug(message, *args, **kwargs)

    def error(self, message, *args, **kwargs):
        self.logger.error(message, *args, **kwargs)

    def info(self, message, *args, **kwargs):
        self.logger.info(message, *args, **kwargs)

    def log(self, level, message, *args, **kwargs):
        self.logger.log(level, message, *args, **kwargs)

    def reset_level(self):
        self.logger.setLevel(LOGGING_LEVEL)

    def separate(self):
        self.info(_CHAIN)

    def warning(self, message, *args, **kwargs):
        self.logger.warning(message, *args, **kwargs)

    def add_file(self, file: Path):
        file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = FileHandler(file)
        file_handler.setFormatter(Formatter(fmt=LOG_FILE_FORMAT, datefmt=LOG_FILE_DATE_FORMAT))
        self.add_handler(file_handler)

    def add_handler(self, handler):
        self.logger.addHandler(handler)

    def log_writer(self, level=logging.INFO):
        return self.__LogWriter(self.logger, level)

    class __LogWriter(IOBase):
        def __init__(self, _logger: logging.Logger, _level: int):
            self._logger = _logger
            self._level = _level

        def write(self, message):
            if len(message.strip("\n\r")):
                self._logger.log(self._level, message)
