#!/usr/bin/env python3
"""
Copyright (c) 2019 Nuance Communications, Inc.
 
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import datetime
import json
import secrets
import uuid
from threading import RLock
from typing import Union, List, Dict, Optional
from urllib.parse import urlparse

import pydicom
import pydicom.uid


__version__ = "1.6.0.61"

###
# System, code, and display values for Codings
###
AI_TECHNIQUE_CODE = "246501002"
AI_TECHNIQUE_DISPLAY = "AI technique"
SNOMED_SYSTEM = "http://snomed.info/sct"
NUANCE_AI_SYSTEM = "http://nuancepowerscribe.com/ai"
NUANCE_SAF_SYSTEM = "http://nuancepowerscribe.com/saf"
SUMMARY_CODE = "RID13170"
SUMMARY_DISPLAY = "impression section"
RADLEX_SYSTEM = "http://radlex.org"
DICOM_SYSTEM = "http://dicom.nema.org/resources/ontology/DCM"

###
# Qualifier "Enumeration" (not an actual enum)
###
FINDING_PRESENT_QUALIFIER = "Present"
FINDING_INDETERMINATE_QUALIFIER = "Indeterminate"
FINDING_ABSENT_QUALIFIER = "Absent"

###
# FHIR Key Constants
###
_FHIR_CODE = "code"
_FHIR_TYPE = "type"
_FHIR_SYSTEM = "system"
_FHIR_UNIT = "unit"
_FHIR_USE = "use"
_FHIR_VALUE = "value"
_FHIR_VALUE_BOOLEAN = "valueBoolean"
_FHIR_VALUE_CODEABLE_CONCEPT = "valueCodeableConcept"
_FHIR_VALUE_INTEGER = "valueInteger"
_FHIR_VALUE_STRING = "valueString"
_FHIR_VALUE_QUANTITY = "valueQuantity"


def _open_dicom(image: Union[pydicom.Dataset, str]):
    if isinstance(image, pydicom.Dataset):
        return image
    else:
        return pydicom.dcmread(image)


def _validate_system(system: str = None):
    if system is not None:
        validate = urlparse(system)
        if not all([validate.scheme, validate.netloc]):
            raise ValueError("System input should be a url")
        else:
            pass
    else:
        pass


def _create_value_quantity(value: float, unit: str = None, system: str = None, code: str = None, comparator: str = None) -> Dict[str, str]:
    _validate_system(system)
    value_quantity = {
        _FHIR_VALUE: value,
        "unit": unit,
        _FHIR_SYSTEM: system,
    }
    if code is not None:
        value_quantity[_FHIR_CODE] = code
    if comparator is not None:
        value_quantity["comparator"] = comparator
    return value_quantity


def _create_coding(code: str, display: Optional[str], system: str):
    _validate_system(system)
    coding = {
        _FHIR_CODE: code,
        _FHIR_SYSTEM: system
    }
    if display is not None:
        coding["display"] = display
    return coding


class DiagnosticReportException(Exception):
    pass


class FindingQualifierException(DiagnosticReportException):
    pass


# DiagnosticReport Object
class DiagnosticReport:
    def __init__(self, conclusion=None, divtext=None):
        self._device_count = 0
        self._study_count = 0
        self._observation_count = 0
        self._ai_technique: Optional["DiagnosticReport.Observation"] = None
        self._summary: Optional["DiagnosticReport.Observation"] = None
        self.id = str(uuid.UUID(bytes=secrets.token_bytes(16), version=4))  # uuid.uuid4() uses os instead of secrets!
        self.resourceType = "DiagnosticReport"
        self.category = [DiagnosticReport.Code("RAD", "Radiology", "http://terminology.hl7.org/CodeSystem/v2-0074")]

        self.code = DiagnosticReport.Code("68604-8", "Radiology Diagnostic study note", "http://loinc.org")

        self.conclusion = conclusion
        self.effectiveDateTime = datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat()
        self.contained = []
        self.imagingStudy = []
        self.result = []
        self.status = "final"
        self.subject = None

        self.__div = divtext

    def __get_from_reference(self, reference) -> "Optional[Study]":
        for contained in self.contained:
            if contained.id == reference.reference[1:]:
                return contained

    @property
    def study(self) -> "Study":
        return self.studies[0]

    @property
    def studies(self) -> "List[Study]":
        return [self.__get_from_reference(imaging_study) for imaging_study in self.imagingStudy]

    @property
    def prior_studies(self) -> "List[Study]":
        return self.studies[1:]

    @property
    def div(self) -> Optional[str]:
        if self.__div:
            return self.__div
        elif self.conclusion is not None:
            return '<div xmlns="http://www.w3.org/1999/xhtml"><p>' + self.conclusion + "</p></div>"
        return None

    @div.setter
    def div(self, new_div):
        self.__div = new_div

    @property
    def text(self) -> Dict:
        return {
            "status": "generated",
            "div": self.div
        }

    def get_study(self, study_id: str = "", study_uid: str = "", accession: str = "", dicom: Optional[pydicom.Dataset] = None) -> "Optional[Study]":
        for _study in self.studies:
            if study_id and _study.id == study_id:
                return _study
            if study_uid and _study.study_uid == study_uid:
                return _study
            if accession and _study.accession == accession:
                return _study
            if dicom and _study.study_uid == dicom.StudyInstanceUID:
                return _study
        return None

    class MyEncoder(json.JSONEncoder):
        def default(self, o):  # pylint: disable=E0202
            try:
                to_json = {
                    k: v
                    for (k, v) in o.__dict__.items()
                    if not k.startswith("_") and v is not None
                }
                if isinstance(o, DiagnosticReport) and o.div is not None:
                    to_json.update({
                        "text": o.text,
                    })
                return to_json
            except AttributeError:
                # Return primitives for "fancy" primitives (like Numpy's version of float)
                try:
                    # Convert whole numbers to integers
                    if float(o) == int(0):
                        return int(0)
                    else:
                        return float(o)
                except ValueError:
                    # Everything else is a string
                    return str(o)

    class Code:
        def __init__(self, code: str, display: Optional[str], system: str, text=None):
            _validate_system(system)
            self.coding = [_create_coding(code, display, system)]
            self.text = text

        def add_coding(self, code, display, system):
            self.coding.append(_create_coding(code, display, system))

    def to_text(self) -> str:
        """
        return:
          a JSON formatted string to serialize DiagnosticReport object 
        """
        return json.dumps(self, indent=2, cls=DiagnosticReport.MyEncoder)

    def write_to_file(self, filename):
        """
        Parameter:
          filename:     the name of destination output file
        """
        with open(filename, "w") as f:
            f.write(self.to_text())
            f.flush()

    class Reference:
        # Reference example: "#Study1"
        def __init__(self, target_id):
            self.reference = "#" + target_id

    class Device:
        # Device stands the AI Service
        def __init__(self, device_id, manufacturer, name, version):
            self.id = device_id
            self.resourceType = "Device"
            self.manufacturer = manufacturer
            self.deviceName = [{"name": name, _FHIR_TYPE: "model-name"}]
            self.version = [{_FHIR_VALUE: version}]

    def add_device(self, device_id, manufacturer, name, version) -> Device:
        """
        Parameters:
            device_id:     the id of the device
            manufacturer:   the producer of the device
            name:          device name
            version:       device version
        return:
          a Device object
        """
        self._device_count += 1
        device_ = DiagnosticReport.Device(device_id, manufacturer, name, version)
        self.contained.append(device_)
        if self._device_count == 1:
            self.subject = DiagnosticReport.Reference(device_.id)
        return device_

    class Patient:
        # the subject that this study is about
        def __init__(self, mrn):
            self.id = "patient1"
            self.resourceType = "Patient"
            self.identifier = [
                {
                    _FHIR_TYPE: DiagnosticReport.Code("MR", None, "http://terminology.hl7.org/CodeSystem/v2-0203"),
                    _FHIR_USE: "usual",
                    _FHIR_VALUE: str(mrn),
                }
            ]

    def __add_patient(self, mrn) -> Patient:
        patient = DiagnosticReport.Patient(mrn)
        self.contained.append(patient)
        return patient

    class Study:
        # The ImageStudy that carries the information
        def __init__(
            self, study_id, dicom, procedure_code, procedure_display, procedure_text
        ):
            self.id = study_id
            self.resourceType = "ImagingStudy"
            self.__accession = dicom.AccessionNumber
            self.__study_uid = dicom.StudyInstanceUID
            self.identifier = [
                {
                    _FHIR_TYPE: DiagnosticReport.Code("ACSN", None, "http://terminology.hl7.org/CodeSystem/v2-0203"),
                    _FHIR_USE: "usual",
                    _FHIR_VALUE: self.__accession,
                },
                {
                    _FHIR_TYPE: DiagnosticReport.Code("110180", "Study Instance UID", DICOM_SYSTEM, ),
                    _FHIR_USE: "official",
                    _FHIR_VALUE: self.__study_uid,
                }
            ]

            self.status = "available"
            self.subject = {"reference": "#patient1"}
            self.procedureCode = [DiagnosticReport.Code(procedure_code, procedure_display, "http://loinc.org", procedure_text)]
            self.started = None

            if dicom.StudyDate != "" or dicom.Study != "":
                try:
                    date = dicom.StudyDate + dicom.StudyTime
                    if "." in date:
                        if "+" in date or "-" in date:
                            self.started = datetime.datetime.strptime(
                                str(date), "%Y%m%d%H%M%S.%f%z"
                            ).isoformat()
                        else:
                            self.started = datetime.datetime.strptime(
                                str(date) + "+0000", "%Y%m%d%H%M%S.%f%z"
                            ).isoformat()
                    else:
                        if "+" in date or "-" in date:
                            self.started = datetime.datetime.strptime(
                                str(date), "%Y%m%d%H%M%S%z"
                            ).isoformat()
                        else:
                            self.started = datetime.datetime.strptime(
                                str(date) + "+0000", "%Y%m%d%H%M%S%z"
                            ).isoformat()
                except Exception:
                    pass
            else:
                pass

        @property
        def accession(self) -> str:
            return self.__accession

        @property
        def study_uid(self) -> str:
            return self.__study_uid

    def __add_study_common(
        self, dicom, procedure_code, procedure_display, procedure_text
    ):
        self._study_count += 1
        study_id = "study" + str(self._study_count)
        study_ = DiagnosticReport.Study(
            study_id, dicom, procedure_code, procedure_display, procedure_text
        )
        self.contained.append(study_)
        return study_

    def set_study(self, dcm, procedure_code, procedure_display, procedure_text) -> Study:
        """
        Parameters:
            dcm:               the filename of a dicom file in the study
            procedure_code:    the code for procedure
            procedure_display: display of the procedure
            procedure_text:    the supplemental text for the procedure.
        return:
          a Study object
        """
        if len(self.imagingStudy) == 0:
            dicom = _open_dicom(dcm)
            self.__add_patient(dicom.PatientID)
            study_ = self.__add_study_common(
                dicom, procedure_code, procedure_display, procedure_text
            )
            self.imagingStudy.append(DiagnosticReport.Reference(study_.id))
            if study_.started is not None:
                self.effectiveDateTime = study_.started
            return study_
        else:
            raise AssertionError("Main Study already exists")

    def add_prior(self, dcm, procedure_code, procedure_display, procedure_text) -> Study:
        """
        Parameters:
            dcm:               the filename of a dicom file in the study
            procedure_code:    the code for procedure
            procedure_display: display of the procedure
            procedure_text:    the supplemental text for the procedure.
        return:
          a Study object
        """
        dicom = _open_dicom(dcm)
        study_ = self.__add_study_common(
            dicom, procedure_code, procedure_display, procedure_text
        )
        study_.started = None  # Remove this is PowerScribe changes how it processes FHIR
        self.imagingStudy.append(DiagnosticReport.Reference(study_.id))
        return study_

    class Observation:
        __lock = RLock()

        def __init__(
            self,
            ob_id,
            derive_from: Union[None, "DiagnosticReport.Study", "DiagnosticReport.Observation"],
            observation_code,
            observation_text,
            observation_system,
            dicom=None,
            body_part_code=None,
            body_part_text=None,
            note=None,
            additional_code=None,
            additional_text=None,
            additional_system=None,
        ):
            if dicom is not None:
                dicom = _open_dicom(dicom)
            self.id = ob_id
            self.resourceType = "Observation"
            if body_part_code is not None:
                self.bodySite = DiagnosticReport.Code(body_part_code, body_part_text, RADLEX_SYSTEM)

            if note is not None:
                self.note = [{"text": note}]

            self.code = DiagnosticReport.Code(observation_code, observation_text, observation_system)

            if additional_code is not None:
                self.code.add_coding(additional_code, additional_text, additional_system)

            self.valueString = (
                self.valueBoolean
            ) = (
                self.valueInteger
            ) = self.valueQuantity = self.valueCodeableConcept = None

            self.component = self.Component(self.__lock, dicom)
            self.status = "final"
            if derive_from is not None:
                self.derivedFrom = [DiagnosticReport.Reference(derive_from.id)]

            self.hasMember = None

            self.device = None
            self._probability_index = -1
            self._qualifier_index = -1
            self._summary_index = -1
            self._tracking_id_index = -1
            self._tracking_uid_index = -1
            try:
                self.set_tracking_id(dicom.TrackingID)  # tracking ID is required if trackingUID is set
                self.set_tracking_uid(dicom.TrackingUID)
            except AttributeError:
                pass

        def get_tracking_uid(self) -> Optional[str]:
            if self._tracking_uid_index == -1:
                return None
            return self.component[self._tracking_uid_index][_FHIR_VALUE_STRING]

        def set_derive_from(self, derived_from):
            """
            Parameter: 
                observation:     the parent observation which self is derived from
            """
            self.derivedFrom = [DiagnosticReport.Reference(derived_from.id)]
            try:
                derived_from.hasMember.append(DiagnosticReport.Reference(self.id))
            except AttributeError:
                derived_from.hasMember = [DiagnosticReport.Reference(self.id)]

        def set_device(self, _device):
            """
            Parameter:
                device:     the device used to detect this finding
            """
            self.device = DiagnosticReport.Reference(_device.id)

        def set_note(self, note: str):
            """
            Parameters:
                note:     the new-added note
            """
            self.note = note

        def set_value_string(self, value: str):
            """
            Parameters:
                value:     the value that will be set to Observation
            """
            if self.__check_value_exist(0):
                if isinstance(value, str) is False:
                    raise ValueError("Input must be a string")
                else:
                    # set Observation's value to the input string. Note: only one value allowed in Observation level
                    self.valueString = value
            else:
                raise ValueError(
                    "Value already exists, not allowed two values in one observation"
                )

        def set_value_integer(self, value: int):
            """
            Parameters:
                value:     the value that will be set to Observation
            """
            if self.__check_value_exist(1):
                if isinstance(value, int) is False:
                    raise ValueError("Input must be an Integer")
                else:
                    # set Observation's value to the input integer. Note: only one value allowed in Observation level
                    self.valueInteger = value
            else:
                raise ValueError(
                    "Value already exists, not allowed two values in one observation"
                )

        def set_value_boolean(self, value: bool):
            """
            Parameters:
                value:     the value that will be set to Observation
            return:
            """
            if self.__check_value_exist(2):
                if isinstance(value, bool) is False:
                    raise ValueError("Input must be a Bool")
                else:
                    # set Observation's value to the input boolean value. Note: only one value allowed in Observation level
                    self.valueBoolean = value
            else:
                raise ValueError(
                    "Value already exists, not allowed two values in one observation"
                )

        def set_value_quantity(
            self, value: float, unit: str = None, system: str = None, code: str = None, comparator: str = None
        ):
            """
            Parameters:
                value:      value for valueQuantity
                unit:       unit for valueQuantity, default is None
                system:     coding system URL for valueQuantity. Default is None
                code:       code for valueQuantity
                comparator: comparator for valueQuantity
            return:
            """
            if self.__check_value_exist(3):
                # set Observation's value to the inputs. Note: only one value allowed in Observation level
                self.valueQuantity = _create_value_quantity(value, unit, system, code, comparator)
            else:
                raise ValueError(
                    "Value already exists, not allowed two values in one observation"
                )

        def set_value_codeable_concept(
            self, code: str, display: str, system, text: str
        ):
            """
            Parameters:
                code:     code for valueCodeableConcept
                display:  display for valueCodeableConcept
                system:   coding system URL for valueCodeableConcept
                text:     supplemental text for valueCodeableConcept
            return:
            """
            if self.__check_value_exist(4):
                # set Observation's value to the inputs. Note: only one value allowed in Observation level
                self.valueCodeableConcept = DiagnosticReport.Code(code, display, system, text)
            else:
                raise ValueError(
                    "Value already exists, not allowed two values in one observation"
                )

        def __check_value_exist(self, index):
            values = [
                self.valueString,
                self.valueInteger,
                self.valueBoolean,
                self.valueQuantity,
                self.valueCodeableConcept,
            ]
            for i in range(0, len(values) - 1):
                if i == index:
                    pass
                else:
                    if values[i] is None:
                        pass
                    else:
                        return False
            return True

        class Component(list):
            def __init__(self, lock: RLock, dicom: pydicom.Dataset = None):
                super().__init__()
                self.__lock = lock
                if dicom:
                    if dicom.StudyInstanceUID != "":
                        self.add_value_string("110180", "Study Instance UID", DICOM_SYSTEM, str(dicom.StudyInstanceUID))
                    if dicom.SeriesNumber != "":
                        self.add_value_integer("113607", "Series Number", DICOM_SYSTEM, dicom.SeriesNumber)
                    if dicom.SeriesInstanceUID != "":
                        self.add_value_string("112002", "Series Instance UID", DICOM_SYSTEM, str(dicom.SeriesInstanceUID))
                    if dicom.InstanceNumber != "":
                        self.add_value_integer("113609", "Instance Number", DICOM_SYSTEM, dicom.InstanceNumber)
                    if dicom.SOPClassUID != "":
                        self.add_value_string("110181", "SOP Class UID", DICOM_SYSTEM, str(dicom.SOPClassUID))
                    if dicom.SOPInstanceUID != "":
                        self.add_value_string("121126", "SOP Instance UID", DICOM_SYSTEM, str(dicom.SOPInstanceUID))

            def add_value_string(self, code, display, system, value: str):
                """
                Parameters:
                    code:     code for the coding object contained in this component
                    display:  display for the coding object
                    system:   coding system URL for this coding object
                    value:    value of the appropriate type
                return:
                """
                with self.__lock:
                    # add a string value to Observation.component
                    self.append({_FHIR_CODE: DiagnosticReport.Code(code, display, system), _FHIR_VALUE_STRING: str(value)})

            def add_value_integer(self, code, display, system, value: int):
                """
                Parameters:
                    code:      code for the coding object contained in this component
                    display:   display for the coding object
                    system:    coding system URL for this coding object
                    value:     value of the appropriate type
                return:
                """
                if isinstance(value, int) is False:
                    raise ValueError("Value input should be an integer")
                else:
                    with self.__lock:
                        # add a integer value to Observation.component
                        self.append({_FHIR_CODE: DiagnosticReport.Code(code, display, system), _FHIR_VALUE_INTEGER: value})

            def add_value_boolean(self, code, display, system, value: bool):
                """
                Parameters:
                    code:     code for the coding object contained in this component
                    display:  display for the coding object
                    system:   coding system URL for this coding object
                    value:    value of the appropriate type
                return:
                """
                if isinstance(value, bool) is False:
                    raise ValueError("Value input should be an Boolean value")
                else:
                    with self.__lock:
                        # add a boolean value to Observation.component
                        self.append({_FHIR_CODE: DiagnosticReport.Code(code, display, system), _FHIR_VALUE_BOOLEAN: value})

            def add_value_quantity(
                self, code, display, system, value, unit=None, value_system=None, quantity_code=None, comparator=None
            ):
                """
                Parameters:
                    code:           code for the coding object contained in this component
                    display:        display for the coding object
                    system:         coding system URL for this coding object
                    value:          value for valueQuantity
                    unit:           unit for valueQuantity, default is None
                    value_system:   coding system URL for valueQuantity. Default is None
                    quantity_code:  code for this quantity
                    comparator:     comparator for this quantity
                return:
                """
                with self.__lock:
                    # add a Quantity value to Observation.component
                    self.append({_FHIR_CODE: DiagnosticReport.Code(code, display, system), _FHIR_VALUE_QUANTITY: _create_value_quantity(value, unit, value_system, quantity_code, comparator)})

            def add_value_codeable_concept(
                self,
                code,
                display,
                system,
                value_code,
                value_display,
                value_system,
                value_text=None,
            ):
                """
                Parameters:
                    code:            code for the coding object contained in this component
                    display:         display for the coding object
                    system:          coding system URL for this coding object
                    value_code:      code for valueCodeableConcept
                    value_display:   display for valueCodeableConcept
                    value_system:    coding system URL for valueCodeableConcept
                    value_text:      supplemental text for valueCodeConcept
                return:
                """
                # add a codeableConcept value to Observation.component
                with self.__lock:
                    self.append({
                        _FHIR_CODE: DiagnosticReport.Code(code, display, system),
                        _FHIR_VALUE_CODEABLE_CONCEPT: DiagnosticReport.Code(value_code, value_display, value_system, value_text)
                    })

        def set_absent_qualifier(self):
            self.set_qualifier(FINDING_ABSENT_QUALIFIER)

        def set_indeterminate_qualifier(self):
            self.set_qualifier(FINDING_INDETERMINATE_QUALIFIER)

        def set_present_qualifier(self):
            self.set_qualifier(FINDING_PRESENT_QUALIFIER)

        def set_probability(self, probability: float):
            """
            Parameters:
                probability: Probability of this observation
            return:
            """
            if self._probability_index == -1:
                with self.__lock:
                    if self._probability_index == -1:
                        self._probability_index = len(self.component)
                        self.component.add_value_quantity("90090302", "Finding Probability", NUANCE_AI_SYSTEM, probability, "percent", "http://unitsofmeasure.org")
                        return  # stop here
            self.component[self._probability_index][_FHIR_VALUE_QUANTITY][_FHIR_VALUE] = probability

        def set_qualifier(self, qualifier: str):
            """
            Parameters:
                qualifier: One of the following: Present, Indeterminate, or Absent
            return:
            """
            if qualifier.capitalize() in [FINDING_PRESENT_QUALIFIER, FINDING_INDETERMINATE_QUALIFIER, FINDING_ABSENT_QUALIFIER]:
                if self._qualifier_index == -1:
                    with self.__lock:
                        if self._qualifier_index == -1:
                            self._qualifier_index = len(self.component)
                            self.component.add_value_string("90090301", "Finding Qualifier", NUANCE_AI_SYSTEM, qualifier.capitalize())
                            return  # stop here
                self.component[self._qualifier_index][_FHIR_VALUE_STRING] = qualifier.capitalize()
            else:
                raise FindingQualifierException(f"Qualifier must be {FINDING_PRESENT_QUALIFIER}, {FINDING_INDETERMINATE_QUALIFIER}, or {FINDING_ABSENT_QUALIFIER}")

        def set_summary(self, summary: str):
            """
            Parameters:
                summary: A concise summary of the findings in this observation (or findings in prior studies)
            return:
            """
            if self._summary_index == -1:
                with self.__lock:
                    if self._summary_index == -1:
                        self._summary_index = len(self.component)
                        self.component.add_value_string(SUMMARY_CODE, SUMMARY_DISPLAY, RADLEX_SYSTEM, summary)
                        return  # stop here
            self.component[self._summary_index][_FHIR_VALUE_STRING] = summary

        def set_tracking_id(self, tracking_id: str):
            """
            Parameters:
                tracking_id: A text label used for tracking a finding or feature
            return:
            """
            if self._tracking_id_index == -1:
                with self.__lock:
                    if self._tracking_id_index == -1:
                        self._tracking_id_index = len(self.component)
                        self.component.add_value_string("112039", "Tracking Identifier", DICOM_SYSTEM, tracking_id)
                        return  # stop here
            self.component[self._tracking_id_index][_FHIR_VALUE_STRING] = tracking_id

        def set_tracking_uid(self, tracking_uid: Optional[str] = None, prefix: Optional[str] = pydicom.uid.PYDICOM_ROOT_UID) -> str:
            """
            Parameters:
                tracking_uid: A unique identifier for a finding or feature.
                prefix:       The UID prefix to use when creating the UID.
                Default is the *pydicom* root UID ``'1.2.826.0.1.3680043.8.498.'``.
                If not used then a prefix of ``'2.25.'`` will be used with the integer form of a UUID generated using the :func:`uuid.uuid4` algorithm.
            return: the current tracking_uid for this observation
            """
            if tracking_uid is None:
                tracking_uid = pydicom.uid.generate_uid(prefix=prefix)  # Generate a random UUID
            if self._tracking_uid_index == -1:  # check if we have set a tracking uid before
                with self.__lock:  # lock
                    if self._tracking_uid_index == -1:  # check again
                        self._tracking_uid_index = len(self.component)  # set the index to the last position
                        self.component.add_value_string("112040", "Tracking Unique Identifier", DICOM_SYSTEM, tracking_uid)  # build the tracking uid structure in components
                        return tracking_uid  # stop here
            # if the tracking_uid IS set, before OR after locking
            self.component[self._tracking_uid_index][_FHIR_VALUE_STRING] = tracking_uid
            return self.component[self._tracking_uid_index][_FHIR_VALUE_STRING]

    def add_observation(
        self,
        derived_from: Union[None, Study, Observation],
        observation_code,
        observation_text,
        observation_system,
        dcm=None,
        body_part_code=None,
        body_part_text=None,
        note=None,
        additional_code=None,
        additional_text=None,
        additional_system=None,
        observation_id=""
    ) -> Observation:
        """
        Parameters:
            derived_from:          a study or observation object from which this observation is derived
            observation_code:      the code representing the observation
            observation_text:      the text for the observation
            observation_system:    the coding system url for the observation
            dcm:                   file path for dicom file
            body_part_code:        the code representing the body part which this observation is about
            body_part_text:        the text for the body part
            note:
            additional_code:
            additional_text:
            additional_system:
            observation_id:        Override the default Observation ID (finding##)
        Return:
          An Observation object
        """
        # add an Observation to the report
        if observation_id == "":
            self._observation_count += 1
            observation_id = f"finding{self._observation_count}"
        observation = DiagnosticReport.Observation(
            observation_id,
            derived_from,
            observation_code,
            observation_text,
            observation_system,
            dcm,
            body_part_code,
            body_part_text,
            note,
            additional_code,
            additional_text,
            additional_system,
        )
        self.contained.append(observation)
        if isinstance(derived_from, DiagnosticReport.Study) and body_part_code is None:
            raise DiagnosticReportException("Observations derived from an ImagingStudy require a body part")
        self.result.append(DiagnosticReport.Reference(observation.id))
        return observation

    def set_ai_technique(self, ai_technique: str):
        if self._ai_technique is None:
            self._ai_technique = self.add_observation(None, AI_TECHNIQUE_CODE, AI_TECHNIQUE_DISPLAY, SNOMED_SYSTEM, observation_id="finding-ai-technique")
            self._ai_technique.component.add_value_string(AI_TECHNIQUE_CODE, AI_TECHNIQUE_DISPLAY, SNOMED_SYSTEM, ai_technique)
        else:
            self._ai_technique.component[0][_FHIR_VALUE_STRING] = ai_technique

    def set_summary(self, summary: str):
        if self._summary is None:
            self._summary = self.add_observation(None, SUMMARY_CODE, SUMMARY_DISPLAY, RADLEX_SYSTEM, observation_id="finding-summary")
        self._summary.set_summary(summary)


if __name__ == "__main__":
    import pathlib
    import sys

    sample_dicom = pathlib.Path("sampleDicom.dcm")
    sample_prior_dicom = pathlib.Path("samplePriorDicom.dcm")

    if len(sys.argv) > 1:
        sample_dicom = pathlib.Path(sys.argv[1])
        if len(sys.argv) > 2:
            sample_prior_dicom = pathlib.Path(sys.argv[2])

    report = DiagnosticReport(
        divtext='<div xmlns="http://www.w3.org/1999/xhtml"><p><b>Cervical Spine Fracture Narrative</b></p><p>Cervical spine fracture seen on series 7 instance 10 with 87.25% probability.</p></div>',
        conclusion="C-spine fracture present.",
    )

    study = report.set_study(
        dcm=sample_dicom if sample_dicom.exists() else None,
        procedure_code="244933-4",
        procedure_display="CT Cervical Spine w IV Contrast",
        procedure_text="CT C-Spine with contrast",
    )

    if sample_prior_dicom.exists():
        prior_study = report.add_prior(
            dcm=sample_prior_dicom,
            procedure_code="244933-4",
            procedure_display="CT Cervical Spine w IV Contrast",
            procedure_text="CT C-Spine with contrast",
        )

    device = report.add_device(
        "ai-algorithm-details",
        "AI Vendor, LLC",
        "Cervical Spine Fracture Detector",
        "development",
    )

    report.set_ai_technique("Sample Validation Technique")

    new_observation = report.add_observation(
        derived_from=study,
        observation_code="1025",
        observation_text="Cervical Spine Fracture",
        observation_system=NUANCE_SAF_SYSTEM,
        note="C-Spine fracture seen on series 7 instance 10 with 87.25% probability.",
        dcm=sample_dicom,
        body_part_code="RID28674",
        body_part_text="Cervical spine region",
        additional_code="125606003",
        additional_text="Fracture of cervical spine",
        additional_system=SNOMED_SYSTEM,
    )

    new_observation.set_probability(87.25)
    new_observation.set_qualifier(FINDING_PRESENT_QUALIFIER)

    # new_observation.set_tracking_id("Very Important Observation #7")
    observation_tracking_uid = new_observation.set_tracking_uid()

    new_observation.set_summary("No change from prior study")

    report.set_summary("Cervical Spine Fracture Narrative. Cervical spine fracture seen on series 7 instance 10 with 87.25% probability. No change from prior study.")

    report.write_to_file("sample-validation-FHIR.json")
    print("Wrote sample-validation-FHIR.json")
